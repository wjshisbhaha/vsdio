from __future__ import annotations

from pathlib import Path

from docx import Document
from docx.enum.section import WD_SECTION
from docx.enum.table import WD_ALIGN_VERTICAL, WD_TABLE_ALIGNMENT
from docx.enum.text import WD_ALIGN_PARAGRAPH
from docx.oxml import OxmlElement
from docx.oxml.ns import qn
from docx.shared import Inches, Pt, RGBColor


OUT_PATH = Path(__file__).resolve().parent / "L412_双轴扫描控制软件_功能实现说明.docx"


BLUE = "2E74B5"
DARK_BLUE = "1F4D78"
HEADER_FILL = "E8EEF5"
LIGHT_FILL = "F4F8FF"
BORDER = "B8C6D6"
TEXT = "20262E"
MUTED = "5C6672"


def set_cell_shading(cell, fill: str):
    tc_pr = cell._tc.get_or_add_tcPr()
    shd = tc_pr.find(qn("w:shd"))
    if shd is None:
        shd = OxmlElement("w:shd")
        tc_pr.append(shd)
    shd.set(qn("w:fill"), fill)


def set_cell_border(cell, color=BORDER, size="6"):
    tc = cell._tc
    tc_pr = tc.get_or_add_tcPr()
    borders = tc_pr.first_child_found_in("w:tcBorders")
    if borders is None:
        borders = OxmlElement("w:tcBorders")
        tc_pr.append(borders)
    for edge in ("top", "left", "bottom", "right"):
        tag = "w:" + edge
        element = borders.find(qn(tag))
        if element is None:
            element = OxmlElement(tag)
            borders.append(element)
        element.set(qn("w:val"), "single")
        element.set(qn("w:sz"), size)
        element.set(qn("w:space"), "0")
        element.set(qn("w:color"), color)


def set_cell_margins(cell, top=80, start=120, bottom=80, end=120):
    tc_pr = cell._tc.get_or_add_tcPr()
    margins = tc_pr.first_child_found_in("w:tcMar")
    if margins is None:
        margins = OxmlElement("w:tcMar")
        tc_pr.append(margins)
    for name, value in (("top", top), ("start", start), ("bottom", bottom), ("end", end)):
        node = margins.find(qn(f"w:{name}"))
        if node is None:
            node = OxmlElement(f"w:{name}")
            margins.append(node)
        node.set(qn("w:w"), str(value))
        node.set(qn("w:type"), "dxa")


def set_table_width(table, widths_in):
    table.alignment = WD_TABLE_ALIGNMENT.LEFT
    table.autofit = False
    tbl_pr = table._tbl.tblPr
    tbl_w = tbl_pr.find(qn("w:tblW"))
    if tbl_w is None:
        tbl_w = OxmlElement("w:tblW")
        tbl_pr.append(tbl_w)
    total = int(round(sum(widths_in) * 1440))
    tbl_w.set(qn("w:w"), str(total))
    tbl_w.set(qn("w:type"), "dxa")
    tbl_ind = tbl_pr.find(qn("w:tblInd"))
    if tbl_ind is None:
        tbl_ind = OxmlElement("w:tblInd")
        tbl_pr.append(tbl_ind)
    tbl_ind.set(qn("w:w"), "120")
    tbl_ind.set(qn("w:type"), "dxa")

    grid = table._tbl.tblGrid
    if grid is None:
        grid = OxmlElement("w:tblGrid")
        table._tbl.insert(0, grid)
    for child in list(grid):
        grid.remove(child)
    for width in widths_in:
        col = OxmlElement("w:gridCol")
        col.set(qn("w:w"), str(int(round(width * 1440))))
        grid.append(col)

    for row in table.rows:
        for idx, cell in enumerate(row.cells):
            if idx < len(widths_in):
                cell.width = Inches(widths_in[idx])
                tc_pr = cell._tc.get_or_add_tcPr()
                tc_w = tc_pr.find(qn("w:tcW"))
                if tc_w is None:
                    tc_w = OxmlElement("w:tcW")
                    tc_pr.append(tc_w)
                tc_w.set(qn("w:w"), str(int(round(widths_in[idx] * 1440))))
                tc_w.set(qn("w:type"), "dxa")
            cell.vertical_alignment = WD_ALIGN_VERTICAL.CENTER
            set_cell_border(cell)
            set_cell_margins(cell)


def set_paragraph_spacing(paragraph, before=0, after=6, line=1.25):
    fmt = paragraph.paragraph_format
    fmt.space_before = Pt(before)
    fmt.space_after = Pt(after)
    fmt.line_spacing = line


def set_run_font(run, size=None, bold=None, color=None, font="Microsoft YaHei"):
    run.font.name = font
    run._element.rPr.rFonts.set(qn("w:eastAsia"), font)
    if size is not None:
        run.font.size = Pt(size)
    if bold is not None:
        run.bold = bold
    if color:
        run.font.color.rgb = RGBColor.from_string(color)


def add_para(doc, text="", style=None, bold_prefix=None):
    p = doc.add_paragraph(style=style)
    if bold_prefix and text.startswith(bold_prefix):
        r = p.add_run(bold_prefix)
        set_run_font(r, bold=True, color=TEXT)
        r2 = p.add_run(text[len(bold_prefix):])
        set_run_font(r2, color=TEXT)
    else:
        r = p.add_run(text)
        set_run_font(r, color=TEXT)
    set_paragraph_spacing(p)
    return p


def add_bullets(doc, items):
    for item in items:
        p = doc.add_paragraph(style="List Bullet")
        r = p.add_run(item)
        set_run_font(r, color=TEXT)
        set_paragraph_spacing(p, after=4, line=1.25)


def add_numbers(doc, items):
    for item in items:
        p = doc.add_paragraph(style="List Number")
        r = p.add_run(item)
        set_run_font(r, color=TEXT)
        set_paragraph_spacing(p, after=4, line=1.25)


def add_heading(doc, text, level=1):
    p = doc.add_heading("", level=level)
    r = p.add_run(text)
    color = BLUE if level in (1, 2) else DARK_BLUE
    size = {1: 16, 2: 13, 3: 12}.get(level, 11)
    set_run_font(r, size=size, bold=True, color=color)
    before_after = {1: (18, 10), 2: (14, 7), 3: (10, 5)}.get(level, (8, 4))
    set_paragraph_spacing(p, before=before_after[0], after=before_after[1])
    return p


def add_table(doc, headers, rows, widths):
    table = doc.add_table(rows=1, cols=len(headers))
    hdr = table.rows[0].cells
    for i, text in enumerate(headers):
        hdr[i].text = ""
        run = hdr[i].paragraphs[0].add_run(text)
        set_run_font(run, bold=True, color=TEXT)
        set_cell_shading(hdr[i], HEADER_FILL)
    for row in rows:
        cells = table.add_row().cells
        for i, text in enumerate(row):
            cells[i].text = ""
            run = cells[i].paragraphs[0].add_run(str(text))
            set_run_font(run, color=TEXT)
    set_table_width(table, widths)
    for row in table.rows:
        for cell in row.cells:
            for p in cell.paragraphs:
                set_paragraph_spacing(p, after=2, line=1.15)
    doc.add_paragraph()
    return table


def add_callout(doc, title, body):
    table = doc.add_table(rows=1, cols=1)
    cell = table.cell(0, 0)
    set_cell_shading(cell, LIGHT_FILL)
    set_cell_border(cell, color="D6E6FF")
    set_cell_margins(cell, top=120, bottom=120, start=160, end=160)
    p = cell.paragraphs[0]
    r = p.add_run(title + "：")
    set_run_font(r, bold=True, color=BLUE)
    r2 = p.add_run(body)
    set_run_font(r2, color=TEXT)
    set_table_width(table, [6.5])
    doc.add_paragraph()


def configure_doc(doc: Document):
    section = doc.sections[0]
    section.page_width = Inches(8.5)
    section.page_height = Inches(11)
    section.top_margin = Inches(1.0)
    section.bottom_margin = Inches(1.0)
    section.left_margin = Inches(1.0)
    section.right_margin = Inches(1.0)
    section.header_distance = Inches(0.492)
    section.footer_distance = Inches(0.492)

    styles = doc.styles
    for style_name in ("Normal", "List Bullet", "List Number"):
        style = styles[style_name]
        style.font.name = "Microsoft YaHei"
        style._element.rPr.rFonts.set(qn("w:eastAsia"), "Microsoft YaHei")
        style.font.size = Pt(11)
        style.font.color.rgb = RGBColor.from_string(TEXT)
        style.paragraph_format.space_after = Pt(6)
        style.paragraph_format.line_spacing = 1.25

    footer = section.footer.paragraphs[0]
    footer.alignment = WD_ALIGN_PARAGRAPH.CENTER
    r = footer.add_run("L-412 双轴扫描控制软件功能实现说明")
    set_run_font(r, size=9, color=MUTED)


def build():
    doc = Document()
    configure_doc(doc)

    title = doc.add_paragraph()
    title.alignment = WD_ALIGN_PARAGRAPH.LEFT
    r = title.add_run("L-412 双轴扫描控制软件功能与实现说明")
    set_run_font(r, size=22, bold=True, color=DARK_BLUE)
    set_paragraph_spacing(title, before=0, after=4, line=1.15)
    subtitle = doc.add_paragraph()
    r = subtitle.add_run("适用版本：当前项目 L412_XY_Controller_UI_v17；文档类型：功能说明、实现方法、维护参考")
    set_run_font(r, size=10, color=MUTED)
    set_paragraph_spacing(subtitle, after=12, line=1.15)

    add_callout(
        doc,
        "系统定位",
        "本软件用于 L-412 双轴位移台、PI/ACS 运动控制器与 CH375 三路快门的集成控制，支持手动轴控制、坐标范围扫描、Excel 文件扫描、匀速运动曝光、相位图全屏显示、结果 Excel 保存、软件限位和配置持久化。",
    )

    add_heading(doc, "1. 总体架构", 1)
    add_para(
        doc,
        "程序采用 PyQt6 单进程主界面 + QThread 后台工作线程 + 设备适配层的结构。主窗口负责界面、配置、信号连接和日志；设备控制逻辑集中在 device_controllers.py；扫描任务、匀速曝光和限位抓取通过独立线程执行，避免阻塞界面。",
    )
    add_table(
        doc,
        ["层级", "主要文件/类", "职责"],
        [
            ["界面层", "MainWindow、AxisDashboard、AxisCard、SC20Card、ScanControlCard、ScanSettingsCard", "构建页面、显示状态、接收用户操作、触发业务命令。"],
            ["业务编排层", "MainWindow 中的 connect_device、handle_axis_command、build_scan_points、start_scan 等方法", "把界面参数转成设备命令，负责配置保存、扫描启动、异常提示和日志。"],
            ["后台任务层", "PhaseScanWorker、UniformExposureWorker、LimitCaptureWorker、PositionPoller", "执行耗时运动、扫描、限位抓取、状态轮询，通过信号回传进度。"],
            ["设备适配层", "AcsMotionController、CH375ShutterClient", "封装 ACS/SPiiPlus 轴控制和 CH375 快门 HTTP 服务，屏蔽真实硬件、模拟器、软件模拟差异。"],
            ["输出层", "openpyxl、Pillow、FullscreenImageWindow", "查找并显示相位图，把扫描结果和原尺寸图片写入 Excel。"],
        ],
        [1.1, 2.0, 3.4],
    )

    add_heading(doc, "2. 页面与功能模块", 1)
    add_table(
        doc,
        ["页面/区域", "功能", "实现类/方法"],
        [
            ["左侧连接栏", "选择设备型号、连接方式、IP、端口、X/Y 轴号，显示通信状态。", "LeftSidebar.settings、MainWindow.connect_device、disconnect_device"],
            ["轴控制页", "X/Y 轴当前位置、目标移动、SetFPosition、启动/关闭轴、单步/大步/连续运动、限位状态。", "AxisDashboard、AxisCard、handle_axis_command、update_axis_states"],
            ["扫描控制", "输入 X/Y 起止和步进，计算扫描点数，显示扫描进度，开始/暂停/停止扫描。", "ScanControlCard、build_scan_points、refresh_scan_preview、handle_scan_command"],
            ["扫描设置", "扫描模式、运动顺序、速度、稳定时间、快门保持时间、扫描快门、全屏显示器。", "ScanSettingsCard.values、config_values、apply_config"],
            ["匀速扫描设置", "匀速运动轴、终点方向、开快门位置。", "UniformScanSettingsCard.values、UniformExposureWorker"],
            ["CH375 快门控制", "检测/连接 32 位快门服务，手动开关三路快门，定时开关。", "SC20Card、CH375ShutterClient、connect_shutter、start_shutter_timer"],
            ["运动设置", "速度、步进、大步进、加速度、减速度、软件限位、扫描文件与图片文件夹。", "MovementParametersCard、apply_soft_limits_from_ui、save_config"],
            ["状态与日志", "记录软件启动、连接、扫描进度、异常、快门状态和保存结果。", "LogCard.append_line、MainWindow.add_log"],
        ],
        [1.35, 2.95, 2.2],
    )

    add_heading(doc, "3. 设备连接与状态轮询", 1)
    add_para(doc, "连接入口是 MainWindow.connect_device。程序从左侧连接栏读取连接方式、IP、端口、轴号，写入 AcsMotionController.axis_map 后调用 connect。连接成功后更新左侧信息、状态栏、X/Y 轴卡片，并启动 PositionPoller。")
    add_bullets(
        doc,
        [
            "真实 ACS TCP/IP：调用 SPiiPlusPython.OpenCommEthernetTCP 建立通信。",
            "SPiiPlus 模拟器：调用 OpenCommSimulator，用于无实机时验证控制流程。",
            "软件模拟：不依赖 SPiiPlusPython，只在内存中维护位置、使能、运动状态。",
            "状态轮询线程每 200 ms 读取 X/Y 的 AxisStatus，并通过 statesReady 信号回主线程更新 UI。",
        ],
    )
    add_heading(doc, "3.1 轴状态模型", 2)
    add_table(
        doc,
        ["字段", "含义", "来源"],
        [
            ["position", "轴当前位置，单位 mm。", "GetFPosition/GetRPosition/GetPosition 或软件模拟位置。"],
            ["enabled", "轴是否启动。", "MST_ENABLE 位或模拟使能标志。"],
            ["moving", "轴是否运动中。", "MST_MOVE 位或模拟运动标志。"],
            ["negative_limit / positive_limit", "硬件负/正限位是否触发。", "ACS FAULT 位；软件模拟模式不再把软件边界伪装成硬件限位。"],
            ["fault_word / motor_state", "底层故障字和电机状态字。", "GetFault/FAULT、GetMotorState/MST。"],
        ],
        [1.7, 2.6, 2.2],
    )

    add_heading(doc, "4. 轴控制功能实现", 1)
    add_heading(doc, "4.1 启动、关闭、停止", 2)
    add_bullets(
        doc,
        [
            "启动轴：handle_axis_command 接收 enable_axis，调用 AcsMotionController.enable。",
            "关闭轴：先 halt 停止当前轴，再 disable 关闭轴，避免运动中直接失能。",
            "停止：调用 halt，仅停止当前轴，不改变目标位置和软件限位配置。",
        ],
    )
    add_heading(doc, "4.2 绝对移动、相对移动和连续移动", 2)
    add_table(
        doc,
        ["操作", "实现方法", "保护思路"],
        [
            ["移动到", "读取 AxisCard.target，调用 move_absolute。", "先执行 _check_soft_limit，目标超出软件限位时拒绝执行。"],
            ["步进 / 大步进", "使用当前位置 + 步进量，调用 move_relative。", "相对目标也必须落在软件限位内。"],
            ["连续运动", "界面命令不再发无限 Jog，而是移动到当前方向的软件限位目标。", "到边界自动停，避免真实硬件连续运动越过软件边界。"],
            ["SetFPosition", "调用 SetFPosition 修改当前位置显示值。", "执行前 halt，说明该操作不移动电机，只重定义反馈坐标。"],
        ],
        [1.25, 2.7, 2.55],
    )
    add_heading(doc, "4.3 软件限位与硬件限位", 2)
    add_para(doc, "软件限位由运动设置页维护，保存到 app_config.json。运行时 apply_soft_limits_from_ui 会把界面值写入 AcsMotionController.soft_limits。硬件限位只读取 ACS FAULT 中的硬件位，不与软件限位混淆。")
    add_bullets(
        doc,
        [
            "软件限位用于阻止目标点、扫描点和匀速曝光开快门位置越界。",
            "硬件限位用于显示真实控制器反馈的限位触发状态。",
            "软件模拟模式下到达软件边界不会点亮硬件限位红灯，避免误导真实环境判断。",
            "抓取限位功能使用 LimitCaptureWorker 以 Jog 方式寻找硬件限位并写回软件限位输入框。",
        ],
    )

    add_heading(doc, "5. 扫描模式与点位生成", 1)
    add_para(doc, "扫描入口为 MainWindow.start_scan，点位生成集中在 build_scan_points。扫描参数来自轴控制页的扫描控制、扫描设置、匀速扫描设置，以及运动设置页的文件夹/Excel 路径。")
    add_table(
        doc,
        ["扫描模式", "输入参数", "点位生成/执行思路"],
        [
            ["蛇形扫描", "X/Y 起始、结束、步进；运动顺序。", "按 inclusive_values 生成 X/Y 序列；每行或每列交替反向，减少回程距离。"],
            ["栅格扫描", "X/Y 起始、结束、步进；运动顺序。", "按固定顺序生成二维网格点，不做交替反向。"],
            ["文件扫描", "Excel 文件、图片/结果文件夹。", "读取 Excel 每行 X、Y、图片路径；扫描点完全来自文件，坐标范围输入不参与。"],
            ["匀速运动曝光", "匀速轴、终点方向、开快门位置、稳定时间、快门保持。", "先到开快门位置并稳定，再打开快门，同时轴继续向终点匀速运动。"],
        ],
        [1.45, 2.15, 2.9],
    )

    add_heading(doc, "5.1 坐标范围扫描流程", 2)
    add_numbers(
        doc,
        [
            "读取扫描模式、运动顺序、速度、稳定时间、快门保持时间和快门编号。",
            "根据 X/Y 起止和步进生成扫描点，超过 100000 点时拒绝执行。",
            "校验每个点是否位于软件限位内，最多展示前 5 个越界点。",
            "PhaseScanWorker 逐点移动 X/Y，按照“先 X 后 Y”或“先 Y 后 X”等待到位。",
            "查找相位图，全屏显示到指定显示器，等待稳定时间。",
            "打开快门，保持指定时间，关闭快门，记录坐标和图片。",
            "扫描完成后回到第一个扫描点，并写出结果 Excel。",
        ],
    )

    add_heading(doc, "5.2 文件扫描 Excel 读取", 2)
    add_para(doc, "文件扫描使用 openpyxl 读取 Excel。程序支持带表头和无表头两种格式，会对表头做归一化处理，兼容中文列名、英文列名、带单位或符号的列名。")
    add_table(
        doc,
        ["列类型", "支持表头示例", "要求"],
        [
            ["X 坐标", "X、X坐标、X轴、X位置、X轴位置", "必须能转换为数字。"],
            ["Y 坐标", "Y、Y坐标、Y轴、Y位置、Y轴位置", "必须能转换为数字。"],
            ["图片", "图片、图片名称、图片路径、相位图、image、image_path、path", "文件扫描模式下不能为空。"],
        ],
        [1.1, 3.1, 2.3],
    )
    add_bullets(
        doc,
        [
            "图片列为绝对路径时直接使用该文件。",
            "图片列为相对路径或文件名时，从图片/结果文件夹中查找。",
            "文件扫描严格使用 Excel 图片列，不再自动拼接坐标名或切换扩展名。",
            "坐标扫描仍支持按 p_x坐标_p_y坐标.png 规则查找相位图，并兼容常见图片扩展名。",
        ],
    )

    add_heading(doc, "6. 匀速运动曝光实现", 1)
    add_para(doc, "匀速运动曝光由 UniformExposureWorker 执行。该模式只控制一个轴，并使用软件限位中对应轴的正/负边界作为最终终点。")
    add_table(
        doc,
        ["阶段", "动作", "关键实现"],
        [
            ["预校验", "确认开快门位置位于当前位置与目标限位之间。", "根据 target_limit 计算 target，并检查 preset 是否在 start 与 target 之间。"],
            ["到开快门位置", "移动到 preset 并等待到位。", "move_absolute(axis, preset) + _wait_axis。"],
            ["稳定等待", "到位后等待 stable_ms。", "_sleep_interruptible(stable_ms, '稳定')，支持停止中断。"],
            ["开快门并继续运动", "打开指定快门，同时向终点继续运动。", "_open_shutter 后 move_absolute(axis, target)。"],
            ["保持后关闭", "快门保持倒计时结束立即关闭。", "根据 hold_deadline 计算剩余时间；remain_ms <= 0 时 _close_shutter。"],
            ["终点完成", "轴继续到软件限位终点。", "到 target 稳定 3 次且快门已关闭后完成。"],
        ],
        [1.2, 2.2, 3.1],
    )

    add_heading(doc, "7. CH375 快门控制", 1)
    add_para(doc, "主程序是 64 位 Python，而 CH375 DLL 通常需要 32 位环境加载。为避免位数冲突，项目设计了 32 位 shutter32_server.py 作为本地 HTTP 服务，主程序通过 CH375ShutterClient 调用。")
    add_table(
        doc,
        ["能力", "HTTP/客户端方法", "实现思路"],
        [
            ["服务检测", "health、probe", "确认服务在线、Python 位数、OpenDevice/CloseDevice 是否可用。"],
            ["连接快门", "connect_shutter", "真实模式下检查 32 位服务并先发送关闭命令，确保安全状态。"],
            ["手动开关", "open_shutter、close_shutter", "三路快门分别对应 0x8A、0x4A、0x2A；关闭命令为 0x0A。"],
            ["定时控制", "start_shutter_timer、_timer_open、_timer_close", "用 QTimer 实现延时打开、保持、延时关闭，并实时刷新倒计时。"],
            ["扫描联动", "PhaseScanWorker / UniformExposureWorker", "扫描线程按流程调用快门客户端，停止或异常时尽力关闭快门。"],
        ],
        [1.2, 2.0, 3.3],
    )

    add_heading(doc, "8. 相位图显示与结果 Excel", 1)
    add_heading(doc, "8.1 全屏显示", 2)
    add_para(doc, "FullscreenImageWindow 使用无边框、置顶窗口在指定显示器全屏显示相位图。图片保持比例缩放，Esc 可关闭。显示器列表由 QApplication.screens() 读取，并保存选中的 display_index。")
    add_heading(doc, "8.2 结果 Excel", 2)
    add_para(doc, "扫描完成后 PhaseScanWorker 使用 openpyxl 写入结果 Excel。每条记录包含序号、X/Y 坐标、图片名称、图片路径、原始分辨率和原尺寸图片。")
    add_bullets(
        doc,
        [
            "结果文件名格式：scan_result_年月日_时分秒.xlsx。",
            "图片以原始像素尺寸插入，不缩放、不裁剪。",
            "行高按图片像素高度换算，超过 Excel 单行高度上限时使用多行合并。",
            "图片列宽按最大图片宽度换算，受 Excel 最大列宽限制。",
        ],
    )

    add_heading(doc, "9. 配置保存与恢复", 1)
    add_para(doc, "配置文件为项目目录下 app_config.json。程序启动时 load_config 读取，保存时 save_config 写入。保存动作在点击“保存设置”、选择文件夹/文件、扫描启动前、限位抓取完成和关闭程序时触发。")
    add_table(
        doc,
        ["配置分组", "保存内容"],
        [
            ["scan", "坐标范围、扫描模式、运动顺序、扫描速度、稳定时间、快门保持时间、扫描快门、显示器、匀速扫描参数、运动参数、软件限位、图片/结果文件夹、文件扫描 Excel。"],
            ["shutter", "32 位快门服务地址。"],
            ["ui", "页面缩放比例 zoom。"],
            ["saved_at", "保存时间戳，便于判断配置更新时间。"],
        ],
        [1.3, 5.2],
    )

    add_heading(doc, "10. 页面缩放与布局", 1)
    add_para(doc, "主窗口支持顶部 - / 100% / + 控件，以及 Ctrl+鼠标滚轮、Ctrl++、Ctrl+-、Ctrl+0 快捷键。实现方法是保留原始 QSS，在 _apply_zoom_style 中用正则按 zoom_factor 缩放 font-size，并为主内容区域设置最小尺寸。页面主体包在 QScrollArea 中，小窗口或放大后可滚动。")

    add_heading(doc, "11. 线程、信号与异常处理", 1)
    add_table(
        doc,
        ["线程", "职责", "中断/异常策略"],
        [
            ["PositionPoller", "周期读取 X/Y 状态。", "读取失败发 pollError 并停止轮询。"],
            ["PhaseScanWorker", "普通扫描和文件扫描。", "stop 设置停止标志、halt_all、关闭快门；异常时 closeImageRequested 并发 scanError。"],
            ["UniformExposureWorker", "匀速运动曝光。", "stop 停轴并关闭快门；保持期间可停止，异常时确保快门关闭。"],
            ["LimitCaptureWorker", "自动抓取 X/Y 正负硬件限位。", "停止时 halt；抓取成功把限位写回 UI 并保存配置。"],
        ],
        [1.45, 2.35, 2.7],
    )
    add_para(doc, "设计思路是：耗时动作不在 UI 线程执行；线程只通过 pyqtSignal 回传状态；所有硬件危险动作在停止或异常路径中尽量执行 halt 和 close_shutter。")

    add_heading(doc, "12. 关键数据流", 1)
    add_table(
        doc,
        ["流程", "数据流"],
        [
            ["连接控制器", "LeftSidebar.settings -> MainWindow.connect_device -> AcsMotionController.connect -> PositionPoller -> AxisCard.set_runtime_state"],
            ["手动轴移动", "AxisCard 按钮 -> axisCommandRequested -> handle_axis_command -> AcsMotionController.move_absolute/move_relative/halt"],
            ["普通扫描", "ScanControlCard/ScanSettingsCard/MovementParametersCard -> build_scan_points -> PhaseScanWorker -> 运动/显示/快门/Excel"],
            ["文件扫描", "Excel -> read_file_scan_points -> validate_points_within_limits -> PhaseScanWorker -> 严格图片路径查找"],
            ["匀速曝光", "UniformScanSettingsCard + ScanSettingsCard -> UniformExposureWorker -> 到预设位置/稳定/开快门/继续运动/关闭快门"],
            ["配置恢复", "app_config.json -> load_config -> apply_config -> apply_soft_limits_from_ui"],
        ],
        [1.55, 4.95],
    )

    add_heading(doc, "13. 安全设计与边界条件", 1)
    add_bullets(
        doc,
        [
            "所有轴移动命令执行前要求控制器已连接，且目标轴已启动。",
            "绝对/相对/扫描/匀速预设位置均检查软件限位。",
            "界面连续运动改为移动到软件限位目标，防止无限 Jog 越界。",
            "扫描启动前要求 X/Y 两轴启动，快门服务已连接或启用模拟。",
            "文件扫描图片列不能为空，避免误用自动坐标命名。",
            "停止扫描会 halt_all，并尝试关闭快门和关闭全屏图。",
            "真实硬件限位显示只来自控制器 FAULT 硬件位，软件模拟不伪造硬件限位。",
        ],
    )

    add_heading(doc, "14. 后续维护建议", 1)
    add_table(
        doc,
        ["方向", "建议"],
        [
            ["硬件安全", "若控制器支持控制器内部软件限位，建议同时下发到 ACS 层，形成 UI 软件限位 + 控制器限位双保险。"],
            ["状态诊断", "增加故障字详细解码，把 FAULT/MST 显示为可读状态，便于现场排查。"],
            ["扫描恢复", "可增加断点续扫、失败点重试和扫描任务文件，降低长时间扫描中断风险。"],
            ["配置管理", "可增加配置导入/导出和多套配置方案。"],
            ["测试验证", "为 build_scan_points、Excel 表头识别、软件限位校验、匀速曝光状态机增加单元测试。"],
        ],
        [1.3, 5.2],
    )

    doc.add_section(WD_SECTION.NEW_PAGE)
    add_heading(doc, "附录 A：核心类与方法索引", 1)
    add_table(
        doc,
        ["类/方法", "用途"],
        [
            ["AcsMotionController", "轴控制统一适配层，封装连接、运动参数、位置、状态、移动、停止。"],
            ["CH375ShutterClient", "主程序到 32 位 CH375 服务的 HTTP 客户端。"],
            ["AxisCard / SC20Card / ScanControlCard / ScanSettingsCard", "轴、快门、扫描控制和扫描参数 UI 卡片。"],
            ["MovementParametersCard", "运动参数、软件限位、图片文件夹、文件扫描 Excel、保存设置。"],
            ["PhaseScanWorker.run", "普通扫描/文件扫描的核心执行流程。"],
            ["UniformExposureWorker.run", "匀速运动曝光核心执行流程。"],
            ["LimitCaptureWorker.run", "硬件限位抓取流程。"],
            ["MainWindow.build_scan_points", "扫描模式分发、点位生成、Excel 点位读取入口。"],
            ["MainWindow.save_config/load_config", "配置持久化和启动恢复。"],
            ["MainWindow.handle_axis_command", "手动轴控制命令分发。"],
            ["MainWindow.connect_shutter/start_shutter_timer", "快门连接和定时控制。"],
        ],
        [2.4, 4.1],
    )

    doc.save(OUT_PATH)
    print(OUT_PATH)


if __name__ == "__main__":
    build()
