from __future__ import annotations

import json
import math
import threading
import time
import urllib.error
import urllib.parse
import urllib.request
from dataclasses import dataclass
from typing import Callable, Iterable, Optional

from PyQt6.QtCore import QThread, pyqtSignal

try:
    import SPiiPlusPython as sp  # type: ignore
except Exception:
    sp = None



class DeviceUnavailableError(RuntimeError):
    pass


@dataclass(frozen=True)
class AxisStatus:
    position: float
    enabled: bool
    moving: bool
    negative_limit: bool
    positive_limit: bool
    fault_word: int
    motor_state: int


@dataclass(frozen=True)
class ScanPoint:
    x: float
    y: float


class AcsMotionController:
    """ACS/SPiiPlus 双轴适配层，默认 X=0、Y=1。"""

    # ACS FAULT 变量中的硬件限位位：#RL=bit0，#LL=bit1。
    FAULT_RIGHT_HW = 1 << 0
    FAULT_LEFT_HW = 1 << 1
    FAULT_RIGHT_SW = 1 << 5
    FAULT_LEFT_SW = 1 << 6

    def __init__(
        self,
        axis_map: Optional[dict[str, int]] = None,
        soft_limits: Optional[dict[str, tuple[float, float]]] = None,
    ):
        self.axis_map = axis_map or {"X": 0, "Y": 1}
        self.soft_limits = soft_limits or {"X": (-6.5, 6.5), "Y": (-6.5, 6.5)}
        self.channel = -1
        self.ip = ""
        self.port = 701
        self.connected = False
        self.simulate = False
        self._lock = threading.RLock()
        self._sim_position = {"X": 0.0, "Y": 0.0}
        self._sim_velocity = {"X": 5.0, "Y": 5.0}
        self._sim_enabled = {"X": False, "Y": False}
        self._sim_moving = {"X": False, "Y": False}

    @property
    def library_available(self) -> bool:
        return sp is not None

    def connect(
        self,
        ip: str = "10.0.0.100",
        port: int = 701,
        *,
        use_simulator: bool = False,
        software_simulation: bool = False,
    ) -> int:
        with self._lock:
            self.disconnect(silent=True)
            self.ip = ip.strip()
            self.port = int(port)
            self.simulate = bool(software_simulation)

            if self.simulate:
                self.channel = 0
                self.connected = True
                return self.channel

            if sp is None:
                raise DeviceUnavailableError(
                    "未安装 SPiiPlusPython，请安装 ACS SPiiPlus ADK 中与当前 Python 版本匹配的 whl。"
                )

            if use_simulator:
                fn = getattr(sp, "OpenCommSimulator", None)
                if fn is None:
                    raise DeviceUnavailableError("当前 SPiiPlusPython 没有 OpenCommSimulator。")
                channel = self._call_variants(fn, [tuple(), (True,)], allow_none=False)
            else:
                fn = getattr(sp, "OpenCommEthernetTCP", None)
                if fn is None:
                    raise DeviceUnavailableError("当前 SPiiPlusPython 没有 OpenCommEthernetTCP。")
                channel = self._call_variants(
                    fn,
                    [(self.ip, self.port), (self.ip, self.port, True)],
                    allow_none=False,
                )

            channel = int(channel)
            if channel < 0:
                raise RuntimeError(f"连接失败，通信句柄={channel}")
            self.channel = channel
            self.connected = True
            return channel

    def disconnect(self, silent: bool = False) -> None:
        with self._lock:
            if not self.connected:
                self.channel = -1
                return
            try:
                if not self.simulate and sp is not None and self.channel >= 0:
                    fn = getattr(sp, "CloseComm", None)
                    if fn is not None:
                        self._call_variants(
                            fn,
                            [(self.channel,), (self.channel, True)],
                            kwargs_variants=[{"failure_check": True}, {}],
                        )
            except Exception:
                if not silent:
                    raise
            finally:
                self.connected = False
                self.channel = -1
                self.simulate = False
                self._sim_enabled = {"X": False, "Y": False}
                self._sim_moving = {"X": False, "Y": False}

    def close(self) -> None:
        self.disconnect(silent=True)

    def _require_connected(self) -> None:
        if not self.connected:
            raise RuntimeError("轴控制器尚未连接。")

    def _axis_index(self, axis: str) -> int:
        key = axis.upper()
        if key not in self.axis_map:
            raise ValueError(f"未知轴：{axis}")
        return int(self.axis_map[key])

    @staticmethod
    def _normalise_result(value):
        if isinstance(value, (list, tuple)) and len(value) == 1:
            return value[0]
        try:
            if hasattr(value, "size") and int(value.size) == 1:
                return value.item()
        except Exception:
            pass
        return value

    @staticmethod
    def _call_variants(
        fn: Callable,
        args_variants: Iterable[tuple],
        *,
        kwargs_variants: Optional[Iterable[dict]] = None,
        allow_none: bool = True,
    ):
        errors: list[Exception] = []
        kw_list = list(kwargs_variants or ({"failure_check": True}, {}))
        for args in args_variants:
            for kwargs in kw_list:
                try:
                    result = fn(*args, **kwargs)
                    if result is None and not allow_none:
                        continue
                    return result
                except TypeError as exc:
                    errors.append(exc)
                    continue
                except Exception:
                    raise
        message = "; ".join(str(e) for e in errors[-3:])
        raise TypeError(f"无法匹配当前 SPiiPlusPython 函数签名：{message}")

    def _read_integer_variable(self, name: str, axis_index: int) -> int:
        if sp is None:
            raise DeviceUnavailableError("SPiiPlusPython 不可用。")

        read_variable = getattr(sp, "ReadVariable", None)
        if read_variable is not None:
            value = self._call_variants(
                read_variable,
                [
                    (self.channel, name, axis_index, axis_index),
                    (self.channel, name, axis_index),
                    (self.channel, name),
                ],
                allow_none=False,
            )
            value = self._normalise_result(value)
            if isinstance(value, (list, tuple)):
                value = value[0]
            return int(value)

        read_integer = getattr(sp, "ReadInteger", None)
        if read_integer is not None:
            value = self._call_variants(
                read_integer,
                [
                    (self.channel, name, axis_index, axis_index, 0, 0),
                    (self.channel, name, axis_index, axis_index),
                    (self.channel, name, axis_index),
                ],
                allow_none=False,
            )
            value = self._normalise_result(value)
            if isinstance(value, (list, tuple)):
                value = value[0]
            return int(value)
        raise DeviceUnavailableError(f"无法读取控制器变量 {name}。")

    def _constant(self, names: Iterable[str], default: int) -> int:
        if sp is not None:
            for name in names:
                if hasattr(sp, name):
                    try:
                        return int(getattr(sp, name))
                    except Exception:
                        pass
        return int(default)

    def _check_soft_limit(self, axis: str, position: float) -> None:
        low, high = self.soft_limits[axis.upper()]
        if not low <= position <= high:
            raise ValueError(
                f"{axis.upper()} 轴目标 {position:.6f} mm 超出软件限位 [{low:.6f}, {high:.6f}] mm"
            )

    def enable(self, axis: str) -> None:
        self._require_connected()
        key = axis.upper()
        if self.simulate:
            self._sim_enabled[key] = True
            return
        fn = getattr(sp, "Enable", None)
        if fn is None:
            raise DeviceUnavailableError("当前 SPiiPlusPython 没有 Enable。")
        index = self._axis_index(key)
        with self._lock:
            self._call_variants(fn, [(self.channel, index)])

    def disable(self, axis: str) -> None:
        self._require_connected()
        key = axis.upper()
        if self.simulate:
            self._sim_enabled[key] = False
            self._sim_moving[key] = False
            return
        fn = getattr(sp, "Disable", None)
        if fn is None:
            raise DeviceUnavailableError("当前 SPiiPlusPython 没有 Disable。")
        index = self._axis_index(key)
        with self._lock:
            self._call_variants(fn, [(self.channel, index)])

    def set_motion_parameters(self, axis: str, velocity: float, acceleration: float, deceleration: float) -> None:
        self._require_connected()
        key = axis.upper()
        velocity = abs(float(velocity))
        acceleration = abs(float(acceleration))
        deceleration = abs(float(deceleration))
        if velocity <= 0:
            raise ValueError("速度必须大于 0。")
        if self.simulate:
            self._sim_velocity[key] = velocity
            return
        index = self._axis_index(key)
        with self._lock:
            for name, value in (
                ("SetVelocity", velocity),
                ("SetAcceleration", acceleration),
                ("SetDeceleration", deceleration),
            ):
                fn = getattr(sp, name, None)
                if fn is not None:
                    self._call_variants(fn, [(self.channel, index, value)])

    def get_position(self, axis: str) -> float:
        self._require_connected()
        key = axis.upper()
        if self.simulate:
            return float(self._sim_position[key])
        index = self._axis_index(key)
        with self._lock:
            for name in ("GetFPosition", "GetRPosition", "GetPosition"):
                fn = getattr(sp, name, None)
                if fn is None:
                    continue
                value = self._call_variants(fn, [(self.channel, index)], allow_none=False)
                value = self._normalise_result(value)
                try:
                    return float(value)
                except Exception:
                    continue
        raise DeviceUnavailableError("当前 SPiiPlusPython 未找到可用的位置读取函数。")

    def set_f_position(self, axis: str, position: float) -> None:
        """
        修改 ACS 反馈位置/当前位置显示值。

        对应 SPiiPlus 的 SetFPosition。该操作通常用于重新定义当前坐标，
        不会移动电机；执行前建议先停止对应轴。
        """
        self._require_connected()
        key = axis.upper()
        position = float(position)
        if self.simulate:
            self._sim_position[key] = position
            return

        index = self._axis_index(key)
        fn = getattr(sp, "SetFPosition", None)
        if fn is None:
            raise DeviceUnavailableError("当前 SPiiPlusPython 没有 SetFPosition。")
        with self._lock:
            # 不同 ADK 版本可能有可选参数差异，兼容常见签名。
            self._call_variants(
                fn,
                [
                    (self.channel, index, position),
                    (self.channel, index, position, True),
                ],
            )

    def get_fault_word(self, axis: str) -> int:
        self._require_connected()
        key = axis.upper()
        if self.simulate:
            return 0

        index = self._axis_index(key)
        fn = getattr(sp, "GetFault", None)
        if fn is not None:
            with self._lock:
                value = self._call_variants(fn, [(self.channel, index)], allow_none=False)
            return int(self._normalise_result(value))
        return self._read_integer_variable("FAULT", index)

    def get_motor_state(self, axis: str) -> int:
        self._require_connected()
        key = axis.upper()
        if self.simulate:
            value = 0
            if self._sim_enabled[key]:
                value |= 1
            if self._sim_moving[key]:
                value |= 4
            return value

        index = self._axis_index(key)
        fn = getattr(sp, "GetMotorState", None)
        if fn is not None:
            with self._lock:
                value = self._call_variants(fn, [(self.channel, index)], allow_none=False)
            return int(self._normalise_result(value))
        return self._read_integer_variable("MST", index)

    def get_axis_status(self, axis: str) -> AxisStatus:
        key = axis.upper()
        position = self.get_position(key)
        fault = self.get_fault_word(key)
        motor_state = self.get_motor_state(key)
        enable_mask = self._constant(("ACSC_MST_ENABLE", "MST_ENABLE"), 1 << 0)
        move_mask = self._constant(("ACSC_MST_MOVE", "MST_MOVE"), 1 << 2)
        return AxisStatus(
            position=position,
            enabled=bool(motor_state & enable_mask),
            moving=bool(motor_state & move_mask),
            negative_limit=bool(fault & self.FAULT_LEFT_HW),
            positive_limit=bool(fault & self.FAULT_RIGHT_HW),
            fault_word=fault,
            motor_state=motor_state,
        )

    def _require_axis_enabled(self, axis: str) -> None:
        status = self.get_axis_status(axis)
        if not status.enabled:
            raise RuntimeError(f"{axis.upper()} 轴尚未启动，请先点击“启动轴”。")

    def move_absolute(self, axis: str, position: float) -> None:
        self._require_connected()
        key = axis.upper()
        position = float(position)
        self._check_soft_limit(key, position)
        self._require_axis_enabled(key)
        if self.simulate:
            self._sim_moving[key] = True
            self._sim_position[key] = position
            self._sim_moving[key] = False
            return
        index = self._axis_index(key)
        fn = getattr(sp, "ToPoint", None)
        if fn is None:
            raise DeviceUnavailableError("当前 SPiiPlusPython 没有 ToPoint。")
        with self._lock:
            self._call_variants(
                fn,
                [(self.channel, 0, index, position), (self.channel, index, position)],
            )

    def move_relative(self, axis: str, distance: float) -> None:
        self._require_connected()
        key = axis.upper()
        self._require_axis_enabled(key)
        target = self.get_position(key) + float(distance)
        self._check_soft_limit(key, target)
        if self.simulate:
            self._sim_moving[key] = True
            self._sim_position[key] = target
            self._sim_moving[key] = False
            return
        index = self._axis_index(key)
        relative_flag = self._constant(("ACSC_AMF_RELATIVE", "AMF_RELATIVE"), 1)
        fn = getattr(sp, "ToPoint", None)
        if fn is None:
            self.move_absolute(key, target)
            return
        with self._lock:
            try:
                self._call_variants(fn, [(self.channel, relative_flag, index, float(distance))])
            except TypeError:
                self.move_absolute(key, target)

    def jog(self, axis: str, velocity: float) -> None:
        self._require_connected()
        key = axis.upper()
        self._require_axis_enabled(key)
        velocity = float(velocity)
        if velocity == 0:
            raise ValueError("连续运动速度不能为 0。")
        if self.simulate:
            low, high = self.soft_limits[key]
            self._sim_moving[key] = True
            self._sim_position[key] = max(low, min(high, self._sim_position[key] + velocity * 0.1))
            self._sim_moving[key] = False
            return
        index = self._axis_index(key)
        fn = getattr(sp, "Jog", None)
        if fn is None:
            raise DeviceUnavailableError("当前 SPiiPlusPython 没有 Jog。")
        with self._lock:
            self._call_variants(fn, [(self.channel, 0, index, velocity), (self.channel, index, velocity)])

    def halt(self, axis: str) -> None:
        self._require_connected()
        key = axis.upper()
        if self.simulate:
            self._sim_moving[key] = False
            return
        index = self._axis_index(key)
        fn = getattr(sp, "Halt", None) or getattr(sp, "Stop", None)
        if fn is None:
            raise DeviceUnavailableError("当前 SPiiPlusPython 没有 Halt/Stop。")
        with self._lock:
            self._call_variants(fn, [(self.channel, index)])

    def halt_all(self) -> None:
        errors = []
        for axis in ("X", "Y"):
            try:
                self.halt(axis)
            except Exception as exc:
                errors.append(exc)
        if len(errors) == 2:
            raise errors[0]


class CH375ShutterClient:
    """
    64 位主程序使用的 CH375 快门桥接客户端。

    真正加载 CH375DLL.dll 的工作由 32 位 Python 进程
    ``shutter32_server.py`` 完成，主程序只通过 localhost HTTP 通信，
    因而不会发生 32/64 位 DLL 冲突。
    """

    def __init__(self, base_url: str = "http://127.0.0.1:37501", timeout: float = 2.0):
        base_url = str(base_url).strip().rstrip("/")
        if not base_url:
            raise ValueError("快门服务地址不能为空。")
        if not base_url.startswith(("http://", "https://")):
            base_url = "http://" + base_url
        self.base_url = base_url
        self.timeout = float(timeout)

    def _request(self, path: str, method: str = "GET") -> dict:
        url = self.base_url + path
        request = urllib.request.Request(
            url,
            data=b"" if method == "POST" else None,
            method=method,
            headers={"Accept": "application/json"},
        )
        try:
            with urllib.request.urlopen(request, timeout=self.timeout) as response:
                raw = response.read().decode("utf-8", errors="replace")
        except urllib.error.HTTPError as exc:
            detail = exc.read().decode("utf-8", errors="replace")
            raise RuntimeError(f"快门服务返回 HTTP {exc.code}: {detail}") from exc
        except urllib.error.URLError as exc:
            raise RuntimeError(
                f"无法连接 32 位快门服务 {self.base_url}：{exc.reason}"
            ) from exc
        try:
            result = json.loads(raw)
        except json.JSONDecodeError as exc:
            raise RuntimeError(f"快门服务返回的不是有效 JSON：{raw!r}") from exc
        if not result.get("ok", False):
            raise RuntimeError(str(result.get("error", "快门服务执行失败")))
        return result

    def health(self) -> dict:
        return self._request("/health", "GET")

    def state(self) -> dict:
        return self._request("/state", "GET")

    def probe(self) -> dict:
        """让 32 位服务真实执行一次 OpenDevice/CloseDevice，不发送快门命令。"""
        return self._request("/probe", "GET")

    def open_shutter(self, shutter_no: int) -> dict:
        shutter_no = int(shutter_no)
        if shutter_no not in (1, 2, 3):
            raise ValueError("快门编号只能是 1、2 或 3。")
        return self._request(f"/open/{shutter_no}", "POST")

    @staticmethod
    def shutters_command(shutter_numbers) -> int:
        shutters = sorted({int(n) for n in shutter_numbers})
        if not shutters or any(n not in (1, 2, 3) for n in shutters):
            raise ValueError("快门编号只能是 1、2 或 3。")
        command = 0x0A
        for number in shutters:
            command |= {1: 0x80, 2: 0x40, 3: 0x20}[number]
        return command

    def write_command(self, value: int) -> dict:
        value = int(value) & 0xFF
        return self._request(f"/command/0x{value:02X}", "POST")

    def close_shutter(self) -> dict:
        return self._request("/close", "POST")


class PositionPoller(QThread):
    statesReady = pyqtSignal(object)
    pollError = pyqtSignal(str)

    def __init__(self, controller: AcsMotionController, interval_ms: int = 200, parent=None):
        super().__init__(parent)
        self.controller = controller
        self.interval_ms = max(50, int(interval_ms))
        self._running = threading.Event()
        self._running.set()

    def stop(self) -> None:
        self._running.clear()

    def run(self) -> None:
        while self._running.is_set():
            try:
                states = {}
                sample_times = {}
                for axis in ("X", "Y"):
                    began = time.monotonic()
                    states[axis] = self.controller.get_axis_status(axis)
                    sample_times[axis] = (began, time.monotonic())
                states['_sample_times'] = sample_times
                self.statesReady.emit(states)
            except Exception as exc:
                self.pollError.emit(str(exc))
                break
            self.msleep(self.interval_ms)


class ScanWorker(QThread):
    pointStarted = pyqtSignal(int, int, float, float)
    pointFinished = pyqtSignal(int, int, float, float)
    scanFinished = pyqtSignal()
    scanStopped = pyqtSignal()
    scanError = pyqtSignal(str)

    def __init__(
        self,
        controller: AcsMotionController,
        points: list[ScanPoint],
        velocity: float,
        acceleration: float,
        deceleration: float,
        timeout_ms: int = 30000,
        tolerance: float = 0.001,
        parent=None,
    ):
        super().__init__(parent)
        self.controller = controller
        self.points = points
        self.velocity = float(velocity)
        self.acceleration = float(acceleration)
        self.deceleration = float(deceleration)
        self.timeout_ms = int(timeout_ms)
        self.tolerance = float(tolerance)
        self._stop_event = threading.Event()
        self._pause_event = threading.Event()
        self._terminal_emitted = False

    def stop(self) -> None:
        self._stop_event.set()
        self._pause_event.clear()
        try:
            self.controller.halt_all()
        except Exception:
            pass

    def set_paused(self, paused: bool) -> None:
        if paused:
            self._pause_event.set()
            try:
                self.controller.halt_all()
            except Exception:
                pass
        else:
            self._pause_event.clear()

    def _emit_stopped_once(self) -> None:
        if not self._terminal_emitted:
            self._terminal_emitted = True
            self.scanStopped.emit()

    def _emit_finished_once(self) -> None:
        if not self._terminal_emitted:
            self._terminal_emitted = True
            self.scanFinished.emit()

    def _wait_if_paused(self) -> bool:
        while self._pause_event.is_set() and not self._stop_event.is_set():
            self.msleep(20)
        return not self._stop_event.is_set()

    def _move_and_wait_interruptible(self, axis: str, target: float) -> bool:
        self.controller.move_absolute(axis, target)
        deadline = time.monotonic() + self.timeout_ms / 1000.0
        stable_count = 0

        while time.monotonic() < deadline:
            if self._stop_event.is_set():
                try:
                    self.controller.halt_all()
                except Exception:
                    pass
                return False

            if self._pause_event.is_set():
                try:
                    self.controller.halt(axis)
                except Exception:
                    pass
                if not self._wait_if_paused():
                    return False
                # 继续扫描时重新发送当前目标。
                self.controller.move_absolute(axis, target)
                deadline = time.monotonic() + self.timeout_ms / 1000.0

            position = self.controller.get_position(axis)
            if math.isfinite(position) and abs(position - target) <= self.tolerance:
                stable_count += 1
                if stable_count >= 3:
                    return True
            else:
                stable_count = 0
            self.msleep(20)

        raise TimeoutError(f"{axis} 轴运动超时，目标={target:.6f} mm")

    def run(self) -> None:
        try:
            for axis in ("X", "Y"):
                status = self.controller.get_axis_status(axis)
                if not status.enabled:
                    raise RuntimeError(f"{axis} 轴未启动，无法开始扫描。")
                self.controller.set_motion_parameters(
                    axis, self.velocity, self.acceleration, self.deceleration
                )

            total = len(self.points)
            for index, point in enumerate(self.points, start=1):
                if self._stop_event.is_set() or not self._wait_if_paused():
                    self._emit_stopped_once()
                    return

                self.pointStarted.emit(index, total, point.x, point.y)

                if not self._move_and_wait_interruptible("X", point.x):
                    self._emit_stopped_once()
                    return
                if not self._move_and_wait_interruptible("Y", point.y):
                    self._emit_stopped_once()
                    return

                self.pointFinished.emit(index, total, point.x, point.y)

            self._emit_finished_once()
        except Exception as exc:
            if self._stop_event.is_set():
                self._emit_stopped_once()
            elif not self._terminal_emitted:
                self._terminal_emitted = True
                self.scanError.emit(str(exc))
