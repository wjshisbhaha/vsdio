@echo off
setlocal
cd /d "%~dp0"

rem ===== 修改为你的 64 位 Python 路径 =====
set "PYTHON64=C:\Python311\python.exe"

"%PYTHON64%" -m pip install -r requirements.txt
pause
endlocal
