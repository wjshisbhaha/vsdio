"""必须使用 32 位 Python 运行，用于直接验证 CH375DLL.DLL。"""

import ctypes
import struct
import sys
from pathlib import Path

DLL_PATH = Path(__file__).resolve().with_name("CH375DLL.DLL")
DEVICE_INDEX = 0
TEST_COMMAND = 0x0A

ULONG = ctypes.c_ulong
BOOL = ctypes.c_int
HANDLE = ctypes.c_void_p


def is_invalid_handle(value: int | None) -> bool:
    if value is None:
        return True
    invalid = (1 << (struct.calcsize("P") * 8)) - 1
    return int(value) in (0, invalid)


def main():
    print("Python:", sys.executable)
    print("Python bitness:", struct.calcsize("P") * 8)
    print("DLL path:", DLL_PATH)
    print("DLL exists:", DLL_PATH.exists())

    if struct.calcsize("P") * 8 != 32:
        raise RuntimeError("此脚本必须用 32 位 Python 运行。")
    if not DLL_PATH.exists():
        raise FileNotFoundError(DLL_PATH)

    # CH375DLL 的 API 使用 WINAPI / stdcall，因此必须使用 WinDLL。
    dll = ctypes.WinDLL(str(DLL_PATH), use_last_error=True)

    # HANDLE WINAPI CH375OpenDevice(ULONG iIndex)
    dll.CH375OpenDevice.argtypes = [ULONG]
    dll.CH375OpenDevice.restype = HANDLE

    # BOOL WINAPI CH375WriteData(ULONG iIndex, PVOID iBuffer, PULONG ioLength)
    dll.CH375WriteData.argtypes = [ULONG, ctypes.c_void_p, ctypes.POINTER(ULONG)]
    dll.CH375WriteData.restype = BOOL

    # VOID WINAPI CH375CloseDevice(ULONG iIndex)
    dll.CH375CloseDevice.argtypes = [ULONG]
    dll.CH375CloseDevice.restype = None

    opened = False
    try:
        ctypes.set_last_error(0)
        raw_handle = dll.CH375OpenDevice(ULONG(DEVICE_INDEX))
        open_result = None if raw_handle is None else int(raw_handle)
        print("CH375OpenDevice handle:", open_result)
        print("Open WinError:", ctypes.get_last_error())
        if is_invalid_handle(open_result):
            raise RuntimeError("OpenDevice 返回无效句柄，请检查驱动、USB 和设备索引。")
        opened = True

        buf = (ctypes.c_ubyte * 1)(TEST_COMMAND)
        length = ULONG(1)

        ctypes.set_last_error(0)
        write_result = int(
            dll.CH375WriteData(
                ULONG(DEVICE_INDEX),
                ctypes.cast(buf, ctypes.c_void_p),
                ctypes.byref(length),
            )
        )
        print(f"CH375WriteData 0x{TEST_COMMAND:02X} result:", write_result)
        print("Actual written length:", length.value)
        print("Write WinError:", ctypes.get_last_error())
        if write_result == 0:
            raise RuntimeError("WriteData 返回 0。")
        if length.value != 1:
            raise RuntimeError(f"实际写入长度异常：{length.value}")
    finally:
        if opened:
            ctypes.set_last_error(0)
            dll.CH375CloseDevice(ULONG(DEVICE_INDEX))
            print(f"CH375CloseDevice({DEVICE_INDEX}) called")
            print("Close WinError:", ctypes.get_last_error())


if __name__ == "__main__":
    main()
