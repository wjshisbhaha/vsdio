@echo off
setlocal
cd /d "%~dp0"

rem ===== 修改为你的 32 位 Python 路径 =====
set "PYTHON32=C:\Python311-32\python.exe"

if not exist "%PYTHON32%" (
    echo [ERROR] 32-bit Python not found:
    echo %PYTHON32%
    echo Please edit start_shutter32.bat and set PYTHON32 correctly.
    pause
    exit /b 1
)

if not exist "CH375DLL.DLL" (
    echo [ERROR] CH375DLL.DLL is missing.
    echo Put the 32-bit CH375DLL.DLL in this project folder.
    pause
    exit /b 1
)

"%PYTHON32%" -c "import struct,sys; bits=struct.calcsize('P')*8; print('Python:',sys.executable); print('Bits:',bits); raise SystemExit(0 if bits==32 else 2)"
if errorlevel 1 (
    echo [ERROR] CH375 service must use 32-bit Python.
    pause
    exit /b 1
)

"%PYTHON32%" shutter32_server.py --host 127.0.0.1 --port 37501 --device-index 0 --dll "%~dp0CH375DLL.DLL"
if errorlevel 1 pause
endlocal
