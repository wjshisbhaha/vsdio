"""Full-screen, original-pixel video playback gated by uniform-scan shutters."""
import threading
import time
from PyQt6.QtCore import Qt, QTimer, QUrl, pyqtSignal
from PyQt6.QtGui import QPainter, QImage
from PyQt6.QtWidgets import QWidget
from PyQt6.QtMultimedia import QMediaPlayer, QVideoSink
from hologram_player import column_entry_indices


def video_columns(entries, count):
    return {column: [entries[i] for i in indices]
            for column, indices in column_entry_indices(entries, count).items()}


class VideoSession:
    """Worker/GUI handoff: no axis movement before the column's video is loaded."""
    def __init__(self):
        self._lock = threading.Lock()
        self.ready = threading.Event()
        self.cancelled = threading.Event()
        self.column = None
        self.error = None

    def request(self, column):
        with self._lock:
            self.column = column
            self.ready.clear()

    def mark_ready(self, column):
        with self._lock:
            if column == self.column and not self.cancelled.is_set():
                self.ready.set()

    def fail(self, message):
        with self._lock:
            self.error = str(message)
            self.ready.set()

    def raise_if_failed(self):
        with self._lock:
            error = self.error
        if error:
            raise RuntimeError('全息视频：' + error)

    def cancel(self):
        self.cancelled.set()
        self.ready.set()

    def wait_ready(self, stopped, timeout=30):
        deadline = time.monotonic() + timeout
        while time.monotonic() < deadline:
            if stopped() or self.cancelled.is_set():
                return False
            self.raise_if_failed()
            if self.ready.wait(0.01):
                self.raise_if_failed()
                return not (stopped() or self.cancelled.is_set())
        raise TimeoutError('全息视频加载超时，请检查视频格式及本机解码器。')


class HologramVideoPlayer(QWidget):
    message = pyqtSignal(str)
    dismissed = pyqtSignal()

    def __init__(self, columns, screen, timeline, session):
        super().__init__(None)
        self.setWindowFlags(Qt.WindowType.FramelessWindowHint | Qt.WindowType.WindowStaysOnTopHint | Qt.WindowType.Tool)
        self.setAttribute(Qt.WidgetAttribute.WA_OpaquePaintEvent)
        self.setGeometry(screen.geometry())
        self.columns = columns
        self.timeline = timeline
        self.session = session
        self.column = None
        self.active_column = None
        self.clip_index = 0
        self.generation = 0
        self._gate_generation = 0
        self._gated = False
        self._loaded = False
        self._play_requested = False
        self._armed = False
        self._finished = False
        self.decoder = None
        self.sink = None
        self.frame = QImage()
        self.records = []
        self.timer = QTimer(self)
        self.timer.setTimerType(Qt.TimerType.PreciseTimer)
        self.timer.setInterval(1)
        self.timer.timeout.connect(self.tick)

    def arm(self):
        self._armed = True
        self.hide()
        self.timer.start()

    def prepare_column(self, column):
        if self._finished or self.session.cancelled.is_set():
            return
        if column not in self.columns:
            self._fail(f'缺少列号 n={column} 的视频。')
            return
        # Closing a gate or preparing another column never shows a loaded frame.
        self._gated = False
        self.hide()
        self.frame = QImage()
        if self.column == column and self.clip_index == 0 and self._loaded:
            self.decoder.stop()
            self.decoder.setPosition(0)
            self._play_requested = False
            self.session.mark_ready(column)
            return
        if self.column == column and self.clip_index == 0 and self.decoder is not None:
            return  # The same asynchronous load is still in flight.
        self.column = column
        self.clip_index = 0
        self._load_current()

    def _release_decoder(self):
        decoder, sink = self.decoder, self.sink
        self.decoder = self.sink = None
        if decoder is not None:
            decoder.stop()
            decoder.setVideoSink(None)
            decoder.deleteLater()
        if sink is not None:
            sink.deleteLater()

    def _load_current(self):
        self._release_decoder()
        self._loaded = False
        self._play_requested = False
        self.frame = QImage()
        self.update()
        entry = self.columns[self.column][self.clip_index]
        decoder = QMediaPlayer(self)
        sink = QVideoSink(self)
        self.decoder, self.sink = decoder, sink
        decoder.setVideoSink(sink)
        # No audio output: phase videos are silent projection data.
        decoder.mediaStatusChanged.connect(lambda status, d=decoder: self._status(d, status))
        decoder.errorOccurred.connect(lambda error, text, d=decoder: self._decoder_error(d, text))
        sink.videoFrameChanged.connect(lambda frame, d=decoder: self._frame_changed(d, frame))
        self.message.emit(f'全息视频第{self.column}列：加载 {entry.path}（Excel第{entry.excel_row}行）。')
        decoder.setSource(QUrl.fromLocalFile(str(entry.path)))

    def _gate_valid(self):
        generation, opened, _ = self.timeline.snapshot()
        return (self._armed and not self._finished and not self.session.cancelled.is_set()
                and self._gated and opened and generation == self._gate_generation)

    def _start_if_open(self):
        if self._loaded and self._gate_valid() and not self._play_requested:
            self._play_requested = True
            self.records.append((self.column, self.clip_index, time.monotonic()))
            self.showFullScreen()
            self.decoder.play()
            self.message.emit(f'全息视频第{self.column}列：播放 {self.columns[self.column][self.clip_index].path.name}。')

    def _status(self, decoder, status):
        if decoder is not self.decoder or self._finished:
            return
        if status in (QMediaPlayer.MediaStatus.LoadedMedia, QMediaPlayer.MediaStatus.BufferedMedia):
            if not decoder.hasVideo():
                self._fail(f'文件没有可用视频轨道：{self.columns[self.column][self.clip_index].path}')
                return
            self._loaded = True
            if self.clip_index == 0:
                self.session.mark_ready(self.column)
            self._start_if_open()
        elif status == QMediaPlayer.MediaStatus.EndOfMedia and self._gate_valid():
            if self.clip_index + 1 < len(self.columns[self.column]):
                self.clip_index += 1
                self._load_current()
            else:
                self.message.emit(f'全息视频第{self.column}列已播完，等待关快门，不循环。')
        elif status == QMediaPlayer.MediaStatus.InvalidMedia:
            self._decoder_error(decoder, decoder.errorString() or '无效视频文件')

    def _decoder_error(self, decoder, text):
        if decoder is self.decoder and not self._finished:
            entry = self.columns[self.column][self.clip_index]
            self._fail(f'{entry.path}：{text}')

    def _fail(self, text):
        self.session.fail(text)
        self._gated = False
        self.hide()
        if self.decoder is not None:
            self.decoder.stop()
        self.message.emit('全息视频错误：' + text)

    def _frame_changed(self, decoder, frame):
        # Drop late decoder frames immediately after a worker requests shutter close.
        if decoder is self.decoder and self._gate_valid() and frame.isValid():
            image = frame.toImage()
            if not image.isNull():
                self.frame = image
                self.update()

    def tick(self):
        generation, opened, _ = self.timeline.snapshot()
        if generation == self.generation or self._finished:
            return
        self.generation = generation
        if not opened:
            self._gated = False
            self.hide()
            self.frame = QImage()
            if self.decoder is not None:
                self.decoder.stop()
            next_column = self.active_column + 1 if self.active_column is not None else None
            self.active_column = None
            if next_column in self.columns:
                self.prepare_column(next_column)
            return
        column = self.timeline.context(generation).get('column')
        if column != self.column or not self._loaded:
            self._fail(f'第{column}列视频尚未准备，未开始播放。')
            return
        self.active_column = column
        self._gate_generation = generation
        self._gated = True
        self._start_if_open()

    def finish(self):
        if self._finished:
            return
        self._finished = True
        self._gated = False
        self.session.cancel()
        self.timer.stop()
        self.hide()
        self.frame = QImage()
        self._release_decoder()

    def paintEvent(self, event):
        painter = QPainter(self)
        painter.fillRect(self.rect(), Qt.GlobalColor.black)
        if not self.frame.isNull() and self._gate_valid():
            dpr = self.devicePixelRatioF()
            painter.scale(1 / dpr, 1 / dpr)
            painter.drawImage(round((self.width() * dpr - self.frame.width()) / 2),
                              round((self.height() * dpr - self.frame.height()) / 2), self.frame)

    def keyPressEvent(self, event):
        if event.key() == Qt.Key.Key_Escape:
            self.close()
        else:
            super().keyPressEvent(event)

    def closeEvent(self, event):
        armed = self._armed
        self._armed = False
        self.finish()
        if armed:
            self.dismissed.emit()
        event.accept()
