import os
os.environ.setdefault('QT_QPA_PLATFORM', 'offscreen')
import tempfile
import threading
import unittest
from pathlib import Path
from unittest.mock import patch
from openpyxl import Workbook
from PyQt6.QtCore import QObject, pyqtSignal
from PyQt6.QtGui import QImage, QColor
from PyQt6.QtWidgets import QApplication
from PyQt6.QtMultimedia import QMediaPlayer
from hologram_player import HologramEntry, HologramSettings, ShutterTimeline, load_hologram_excel
from hologram_video import HologramVideoPlayer, VideoSession, video_columns

app = QApplication.instance() or QApplication([])


class Decoder(QObject):
    MediaStatus = QMediaPlayer.MediaStatus
    mediaStatusChanged = pyqtSignal(object)
    errorOccurred = pyqtSignal(object, str)

    def __init__(self, parent=None):
        super().__init__(parent)
        self.plays = 0
        self.stops = 0
        self.position = 0
        self.url = None

    def setVideoSink(self, sink): pass
    def setSource(self, url): self.url = url
    def hasVideo(self): return True
    def errorString(self): return 'test invalid video'
    def play(self): self.plays += 1
    def stop(self): self.stops += 1
    def setPosition(self, position): self.position = position
    def loaded(self): self.mediaStatusChanged.emit(self.MediaStatus.LoadedMedia)


class Sink(QObject):
    videoFrameChanged = pyqtSignal(object)


class Frame:
    def isValid(self): return True
    def toImage(self):
        image = QImage(123, 87, QImage.Format.Format_RGB32)
        image.fill(QColor('blue'))
        return image


class VideoTests(unittest.TestCase):
    def setUp(self):
        self.tmp = tempfile.TemporaryDirectory()
        self.root = Path(self.tmp.name)
        for name in ('a.mp4', 'b.mp4', 'c.mp4'):
            (self.root / name).write_bytes(b'test-media')
        self.entries = [HologramEntry(self.root / 'a.mp4', 4, 1, 0, 2),
                        HologramEntry(self.root / 'b.mp4', 3, 2, 1, 4),
                        HologramEntry(self.root / 'c.mp4', 2, 1, 2, 6)]
        self.session = VideoSession()
        self.timeline = ShutterTimeline()
        self.patch_decoder = patch('hologram_video.QMediaPlayer', Decoder)
        self.patch_sink = patch('hologram_video.QVideoSink', Sink)
        self.patch_decoder.start(); self.patch_sink.start()
        self.player = HologramVideoPlayer(video_columns(self.entries, 2), app.primaryScreen(),
                                          self.timeline, self.session)
        self.player.arm(); self.player.timer.stop()

    def tearDown(self):
        self.player._armed = False
        self.player.finish(); self.player.close()
        self.patch_sink.stop(); self.patch_decoder.stop()
        self.tmp.cleanup()

    def open_first(self):
        self.session.request(1); self.player.prepare_column(1)
        self.assertFalse(self.session.ready.is_set())
        self.player.decoder.loaded()
        self.assertTrue(self.session.ready.is_set())
        self.assertFalse(self.player.isVisible())
        self.assertEqual(self.player.decoder.plays, 0)
        self.timeline.mark(True, {'column': 1}); self.player.tick()

    def test_excel_video_names_reuse_folder_headers_order_and_duplicates(self):
        path = self.root / 'input.xlsx'
        b = Workbook(); s = b.active
        s.append(['相位图名称', '行号m(X向)', '列号n(Y向)'])
        s.append(['b.mp4', 9, 2]); s.append([None, None, None])
        s.append(['a.mp4', 2, 1]); s.append(['a.mp4', 1, 1])
        b.save(path); b.close()
        columns = video_columns(load_hologram_excel(str(path), str(self.root)), 2)
        self.assertEqual([e.path.name for e in columns[1]], ['a.mp4', 'a.mp4'])
        self.assertEqual([e.excel_row for e in columns[1]], [4, 5])
        self.assertEqual(columns[2][0].path.name, 'b.mp4')
        with self.assertRaisesRegex(ValueError, 'n=3'): video_columns(self.entries, 3)

    def test_settings_mutual_exclusion_and_persistence(self):
        w = HologramSettings()
        w.enabled.setChecked(True); w.video_enabled.setChecked(True)
        self.assertFalse(w.enabled.isChecked())
        self.assertFalse(w.delay.isEnabled())
        self.assertFalse(w.frequency_settings.isEnabled())
        config = w.config_values()
        other = HologramSettings(); other.apply_config(config)
        self.assertEqual(other.config_values(), config)
        self.assertTrue(other.video_enabled.isChecked())
        w.enabled.setChecked(True)
        self.assertFalse(w.video_enabled.isChecked())
        self.assertTrue(w.delay.isEnabled())
        w.close(); other.close()

    def test_open_plays_and_close_drops_late_frame_then_preloads_next_column(self):
        self.open_first()
        first = self.player.decoder
        self.assertEqual(first.plays, 1)
        self.player._frame_changed(first, Frame())
        self.assertEqual((self.player.frame.width(), self.player.frame.height()), (123, 87))
        self.timeline.mark(False)
        # Even before GUI timer processes the close, no late frame may be displayed.
        self.assertFalse(self.player._gate_valid())
        self.player.tick()
        self.assertFalse(self.player.isVisible())
        self.assertTrue(self.player.frame.isNull())
        self.assertEqual(self.player.column, 2)
        self.assertEqual(self.player.decoder.plays, 0)
        next_decoder = self.player.decoder
        self.player._frame_changed(first, Frame())
        first.mediaStatusChanged.emit(QMediaPlayer.MediaStatus.EndOfMedia)
        self.assertIs(self.player.decoder, next_decoder)
        self.assertTrue(self.player.frame.isNull())
        self.session.request(2); self.player.prepare_column(2)
        next_decoder.loaded()
        self.assertTrue(self.session.ready.is_set())
        self.timeline.mark(True, {'column': 2}); self.player.tick()
        self.assertEqual(next_decoder.plays, 1)
        self.assertEqual([r[:2] for r in self.player.records], [(1, 0), (2, 0)])

    def test_same_column_playlist_and_no_loop_at_end(self):
        self.open_first()
        old = self.player.decoder
        old.mediaStatusChanged.emit(QMediaPlayer.MediaStatus.EndOfMedia)
        self.assertEqual(self.player.clip_index, 1)
        self.assertEqual(self.player.decoder.url.toLocalFile(), str(self.root / 'c.mp4'))
        self.player.decoder.loaded()
        current = self.player.decoder
        self.assertEqual(current.plays, 1)
        current.mediaStatusChanged.emit(QMediaPlayer.MediaStatus.EndOfMedia)
        self.assertIs(self.player.decoder, current)
        self.assertEqual(current.plays, 1)
        self.assertEqual(len(self.player.records), 2)

    def test_early_close_does_not_play_remaining_clips(self):
        self.open_first()
        old = self.player.decoder
        self.timeline.mark(False)
        old.mediaStatusChanged.emit(QMediaPlayer.MediaStatus.EndOfMedia)
        self.assertEqual(self.player.clip_index, 0)
        self.player.tick()
        self.assertEqual(self.player.column, 2)
        self.assertEqual(len(self.player.records), 1)

    def test_loading_error_unblocks_worker_and_hides_video(self):
        self.session.request(1); self.player.prepare_column(1)
        self.player.decoder.errorOccurred.emit(1, 'bad codec')
        self.assertTrue(self.session.ready.is_set())
        with self.assertRaisesRegex(RuntimeError, 'bad codec'):
            self.session.wait_ready(lambda: False)
        self.assertFalse(self.player.isVisible())

    def test_load_wait_is_cancellable_and_timeout_is_explicit(self):
        self.assertFalse(self.session.wait_ready(lambda: True))
        with self.assertRaises(TimeoutError): self.session.wait_ready(lambda: False, timeout=0.01)
        self.session.cancel()
        self.assertFalse(self.session.wait_ready(lambda: False))

    def test_finish_releases_decoder_and_cannot_restart(self):
        self.open_first()
        self.player.finish()
        self.assertIsNone(self.player.decoder)
        self.assertFalse(self.player.isVisible())
        self.assertTrue(self.session.cancelled.is_set())
        self.player.prepare_column(2)
        self.assertIsNone(self.player.decoder)

    def test_escape_style_close_requests_scan_stop(self):
        dismissed = []; self.player.dismissed.connect(lambda: dismissed.append(True))
        self.open_first(); self.player.close()
        self.assertEqual(dismissed, [True])
        self.assertTrue(self.session.cancelled.is_set())

    def test_normal_shutter_close_keeps_session_for_next_column(self):
        from main import UniformLineScanWorker
        worker = UniformLineScanWorker(None, {'_hologram_video_session': self.session,
                    '_hologram_timeline': self.timeline}, {}, '', True)
        self.timeline.mark(True, {'column': 1})
        worker._close_shutter()
        self.assertFalse(self.session.cancelled.is_set())
        self.assertFalse(self.timeline.snapshot()[1])
        self.session.request(2)
        self.session.mark_ready(2)
        self.assertTrue(self.session.wait_ready(lambda: False))

    def test_stopping_scan_cancels_pending_video_load(self):
        from main import UniformLineScanWorker
        worker = UniformLineScanWorker(None, {'_hologram_video_session': self.session}, {}, '', True)
        self.session.request(1)
        worker.stop()
        self.assertTrue(self.session.cancelled.is_set())
        self.assertFalse(self.session.wait_ready(lambda: worker._stop_event))
