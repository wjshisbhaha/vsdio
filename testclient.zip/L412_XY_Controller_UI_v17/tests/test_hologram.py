import os
os.environ.setdefault('QT_QPA_PLATFORM', 'offscreen')
import tempfile
import unittest
from pathlib import Path
from unittest.mock import patch
from PyQt6.QtWidgets import QApplication
from PyQt6.QtGui import QImage, QColor
from openpyxl import Workbook
from hologram_player import load_hologram_excel, schedule_offsets, ShutterTimeline, HologramPlayer, HologramSettings

app = QApplication.instance() or QApplication([])

class HologramTests(unittest.TestCase):
    def setUp(self):
        self.temp = tempfile.TemporaryDirectory()
        self.folder = Path(self.temp.name)
        for number in (10, 2, 1):
            image = QImage(32, 32, QImage.Format.Format_RGB32)
            image.fill(QColor('red'))
            image.save(str(self.folder / f'holo{number}.png'))
        self.excel = self.folder / 'holograms.xlsx'
        book = Workbook(); sheet = book.active
        sheet.append(['相位图名称', '行号m(x向)', '行号n(y向)'])
        sheet.append(['holo10.png', 9, 5])
        sheet.append([None, None, None])
        sheet.append(['holo2.png', 1, 0])
        sheet.append(['holo10.png', 1, 0])
        book.save(self.excel); book.close()
        self.paths = [entry.path for entry in load_hologram_excel(str(self.excel))]
        self.timeline = ShutterTimeline()
        self.player = HologramPlayer(self.paths, [0.05, 0.15, 0.2], app.primaryScreen(), self.timeline)

    def tearDown(self):
        self.player.close()
        self.temp.cleanup()

    def test_excel_order_duplicates_blanks_and_variable_rates(self):
        self.assertEqual([p.name for p in self.paths], ['holo10.png', 'holo2.png', 'holo10.png'])
        offsets, _ = schedule_offsets(3, 50, '10，20')
        for a, b in zip(offsets, [0.05, 0.15, 0.2]): self.assertAlmostEqual(a, b)
        for text in ('nan', 'inf', '0', '-1', '10,20,30'):
            with self.assertRaises(ValueError): schedule_offsets(3, 0, text)

    def test_delay_close_and_restart(self):
        with patch('hologram_player.time.monotonic', return_value=100): self.timeline.mark(True)
        with patch('hologram_player.time.monotonic', return_value=100.01): self.player.tick()
        self.assertEqual(self.player.index, -1)
        with patch('hologram_player.time.monotonic', return_value=100.051): self.player.tick()
        self.assertEqual(self.player.index, 0)
        with patch('hologram_player.time.monotonic', return_value=100.07): self.timeline.mark(False)
        with patch('hologram_player.time.monotonic', return_value=101): self.player.tick()
        self.assertEqual(self.player.index, 0)
        with patch('hologram_player.time.monotonic', return_value=102): self.timeline.mark(True)
        for stamp in (102.051, 102.151, 102.201):
            with patch('hologram_player.time.monotonic', return_value=stamp): self.player.tick()
        self.assertEqual(self.player.index, 2)
        self.timeline.mark(False); self.player.tick(); self.player.finish()
        self.assertEqual(self.player.index, 2)
        self.assertFalse(self.player.timer.isActive())

    def test_early_close_and_late_render_report(self):
        with patch('hologram_player.time.monotonic', return_value=10): self.timeline.mark(True)
        with patch('hologram_player.time.monotonic', return_value=10.01): self.player.tick()
        self.timeline.mark(False); self.player.tick()
        self.assertEqual(self.player.index, -1)
        with patch('hologram_player.time.monotonic', return_value=20): self.timeline.mark(True)
        with patch('hologram_player.time.monotonic', return_value=20.08): self.player.tick()
        messages=[]; self.player.message.connect(messages.append); self.player.finish()
        self.assertIn('≥16 ms 共 1 次', messages[0])

    def test_config_roundtrip(self):
        widget=HologramSettings()
        config={'hologram_enabled':True,'hologram_video_enabled':False,'hologram_folder':str(self.folder),'hologram_excel':str(self.excel),
                'hologram_delay_ms':12.5,'hologram_frequencies':'10,20'}
        widget.apply_config(config)
        self.assertEqual(widget.config_values(),config)

    def test_original_pixels_and_shared_cache(self):
        self.assertEqual(self.player.frames[0].width(), 32)
        self.assertEqual(self.player.frames[0].height(), 32)
        self.assertEqual(self.player.frames[0].toImage().pixelColor(0, 0), QColor('red'))
        self.assertIs(self.player.frames[0], self.player.frames[2])
        from PyQt6.QtGui import QImageReader
        self.assertEqual(QImageReader.allocationLimit(), 0)

    def test_labels_are_only_annotations(self):
        book=Workbook(); sheet=book.active
        sheet.append(['相位图名称','行号m（x向）','行号n（y向）'])
        sheet.append(['holo1.png','横向说明',None])
        sheet.append(['holo2.png',-10,2.5])
        book.save(self.excel); book.close()
        entries=load_hologram_excel(str(self.excel))
        self.assertEqual([e.path.name for e in entries],['holo1.png','holo2.png'])
        self.assertEqual(entries[0].m,'横向说明')
        self.assertIsNone(entries[0].n)

    def test_corrected_column_header_preserves_order_and_duplicates(self):
        book = Workbook(); sheet = book.active
        sheet.append(['相位图名称', '行号m(X向)', '列号n(Y向)'])
        sheet.append(['holo1.png', 3, 2])
        sheet.append(['holo2.png', 1, 1])
        sheet.append(['holo1.png', 2, 2])
        book.save(self.excel); book.close()
        entries = load_hologram_excel(str(self.excel))
        self.assertEqual([entry.n for entry in entries], [2, 1, 2])
        self.assertEqual([entry.path.name for entry in entries],
                         ['holo1.png', 'holo2.png', 'holo1.png'])

    def test_missing_image_reports_excel_row(self):
        (self.folder / 'holo2.png').unlink()
        with self.assertRaisesRegex(ValueError,'第 4 行'):
            load_hologram_excel(str(self.excel))

    def test_export_timing_position_and_unshown_rows(self):
        from hologram_report import export_report
        from openpyxl import load_workbook
        player=self.player
        player.report_entries=load_hologram_excel(str(self.excel))
        player.report_config={'hologram_excel':str(self.excel),'hologram_frequencies':'10,20'}
        player.report_directory=self.folder
        player.position_provider=lambda: ({'kind':'匀速扫描线','index':1,'x':5},
            {'X':{'position':4.9,'began':99.9,'ended':99.95},
             'Y':{'position':1.2,'began':99.96,'ended':99.98}})
        with patch('hologram_player.time.monotonic',return_value=100):self.timeline.mark(True)
        for stamp in (100.051,100.151):
            with patch('hologram_player.time.monotonic',return_value=stamp):player.tick()
        with patch('hologram_player.time.monotonic',return_value=100.17):self.timeline.mark(False)
        # Second exposure opens and closes entirely while the GUI is occupied.
        with patch('hologram_player.time.monotonic',return_value=101):self.timeline.mark(True)
        with patch('hologram_player.time.monotonic',return_value=101.01):self.timeline.mark(False)
        path=export_report(player,'扫描停止')
        book=load_workbook(path)
        self.assertEqual(book.sheetnames,['运行摘要','图片切换记录','快门时序'])
        rows=list(book['图片切换记录'].values); headers=rows[0]
        data=[dict(zip(headers,row)) for row in rows[1:]]
        self.assertEqual(len(data),6)
        self.assertAlmostEqual(data[1]['实际间隔(ms)'],100)
        self.assertAlmostEqual(data[1]['实际频率(Hz)'],10)
        self.assertEqual(data[0]['最近反馈X(mm)'],4.9)
        self.assertAlmostEqual(data[0]['X反馈距切图(ms)'],101)
        self.assertEqual(data[2]['记录状态'],'未切换：已关闭快门')
        self.assertIsNone(data[2]['实际频率(Hz)'])
        self.assertEqual(data[0]['相位图名称'],data[2]['相位图名称'])
        self.assertEqual(data[0]['m标注'],'9')
        self.assertIsNone(data[3]['实际相对开门(ms)'])
        self.assertEqual(book['快门时序'].max_row,5)
        book.close()

    def test_column_selection_playback_and_report(self):
        from hologram_player import HologramEntry, column_sequences
        from hologram_report import export_report
        from openpyxl import load_workbook
        entries = [HologramEntry(self.paths[0], 9, 2, 0, 2),
                   HologramEntry(self.paths[1], 8, 1, 0, 3),
                   HologramEntry(self.paths[2], 7, 2, 1, 5)]
        player = self.player
        player.sequences, _ = column_sequences(entries, 2, 50, '10')
        self.assertEqual(player.sequences[1][0], [1])
        self.assertEqual(player.sequences[2][0], [0, 2])
        player.report_entries = entries
        player.report_config = {'mode': '匀速扫描'}
        player.report_directory = self.folder
        with patch('hologram_player.time.monotonic', return_value=100):
            self.timeline.mark(True, {'column': 1, 'index': 1})
        with patch('hologram_player.time.monotonic', return_value=100.051): player.tick()
        self.assertEqual(player.index, 1)
        self.assertFalse(player.running)
        with patch('hologram_player.time.monotonic', return_value=100.2): self.timeline.mark(False)
        player.tick()
        with patch('hologram_player.time.monotonic', return_value=101):
            self.timeline.mark(True, {'column': 2, 'index': 2})
        with patch('hologram_player.time.monotonic', return_value=101.051): player.tick()
        self.assertEqual(player.index, 0)
        with patch('hologram_player.time.monotonic', return_value=101.151): player.tick()
        self.assertEqual(player.index, 2)
        self.assertFalse(player.running)
        self.assertEqual([r['index'] for r in player.records], [1, 0, 2])
        self.assertEqual([r['context']['column'] for r in player.records], [1, 2, 2])
        with patch('hologram_player.time.monotonic', return_value=101.2): self.timeline.mark(False)
        # A complete missed opening must still report only that column's planned images.
        with patch('hologram_player.time.monotonic', return_value=102):
            self.timeline.mark(True, {'column': 1, 'index': 1})
        with patch('hologram_player.time.monotonic', return_value=102.01): self.timeline.mark(False)
        book = load_workbook(export_report(player, '测试'))
        rows = list(book['图片切换记录'].values)
        data = [dict(zip(rows[0], row)) for row in rows[1:]]
        self.assertEqual([r['列号n(Y向)'] for r in data], ['1', '2', '2', '1'])
        self.assertEqual([r['图片序号'] for r in data], [1, 1, 2, 1])
        self.assertEqual([r['源Excel行'] for r in data], [3, 2, 5, 3])
        self.assertEqual(data[-1]['记录状态'], '未切换：已关闭快门')
        self.assertEqual(data[-1]['扫描序号'], 1)
        summary = dict(list(book['运行摘要'].values)[1:])
        self.assertEqual(summary['计划显示总次数'], 4)
        self.assertEqual(summary['未切换次数'], 1)
        book.close()

    def test_column_validation_before_scan(self):
        from hologram_player import HologramEntry, column_sequences
        entries = [HologramEntry(self.paths[0], 99, 1, 0, 2)]
        with self.assertRaisesRegex(ValueError, '缺少列号 n=2'):
            column_sequences(entries, 2, 0, '10')
        for n in (None, 0, -1, 1.5, '文字', True):
            with self.assertRaisesRegex(ValueError, '第 2 行'):
                column_sequences([HologramEntry(self.paths[0], 99, n, 0, 2)], 1, 0, '10')
        with self.assertRaisesRegex(ValueError, '列号 n=1'):
            column_sequences(entries, 1, 0, '10,20')

    def test_uniform_worker_transmits_column_context(self):
        from main import UniformLineScanWorker
        class Motion:
            positions = {'X': 0, 'Y': 0}
            def get_axis_status(self, axis):
                return type('Status', (), {'enabled': True})()
            def set_motion_parameters(self, *args): pass
            def move_absolute(self, axis, target): self.positions[axis] = target
            def get_position(self, axis): return self.positions[axis]
        values = {'x_start': 0, 'x_end': 1, 'x_step': 1, 'y_start': 0, 'y_end': 1,
                  'uniform_shutter_position': 0, 'uniform_shutter_close_position': 1,
                  'stable_ms': 0, 'speed': 1, 'uniform_shutters': [1, 2],
                  '_hologram_timeline': self.timeline}
        worker = UniformLineScanWorker(Motion(), values,
                    {'velocity': 1, 'acceleration': 1, 'deceleration': 1}, '', True)
        errors = []; worker.scanError.connect(errors.append)
        worker.run()
        self.assertEqual(errors, [])
        contexts = [self.timeline.context(gen) for gen, opened, stamp in self.timeline.history() if opened]
        self.assertEqual([c['column'] for c in contexts], [1, 2])
        self.assertEqual([c['x'] for c in contexts], [0, 1])

    def test_worker_shutter_events(self):
        from main import PhaseScanWorker, UniformExposureWorker, UniformLineScanWorker
        for cls in (PhaseScanWorker, UniformExposureWorker, UniformLineScanWorker):
            values={'scan_shutter':1, 'uniform_shutters':[1,2], '_hologram_timeline':self.timeline}
            args=(None, [], values, {}, '', True) if cls is PhaseScanWorker else (None, values, {}, '', True)
            worker=cls(*args)
            worker._open_shutter()
            self.assertTrue(self.timeline.snapshot()[1])
            worker._close_shutter()
            self.assertFalse(self.timeline.snapshot()[1])

if __name__=='__main__': unittest.main()
