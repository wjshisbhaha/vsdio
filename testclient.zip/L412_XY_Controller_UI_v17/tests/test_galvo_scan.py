import os
os.environ.setdefault('QT_QPA_PLATFORM', 'offscreen')
import tempfile
import threading
import time
import unittest
from pathlib import Path
from unittest.mock import patch
from openpyxl import Workbook
from PyQt6.QtWidgets import QApplication
from galvo_scan import GalvoScanRunner, GalvoScanSettings, load_galvo_master
from serial_controller.custom_waveform import Point

app = QApplication.instance() or QApplication([])


class SerialStub:
    """Record serial operations; never open a real serial port."""
    timeout = 0.1
    connected = True
    serial = type('Serial', (), {'baudrate': 115200})()

    def __init__(self):
        self.channel = 0
        self.calls = []
        self.first = threading.Event()
        self.fail = False

    def set_channel(self, channel):
        self.channel = channel

    def stop_waveform(self):
        self.calls.append(('stop', self.channel, None, time.monotonic()))

    def set_mode(self, mode):
        self.calls.append(('mode', self.channel, mode, time.monotonic()))

    def set_voltage(self, value):
        if self.fail:
            raise OSError('test serial failure')
        self.calls.append(('voltage', self.channel, value, time.monotonic()))
        self.first.set()

    def set_displacement(self, value):
        self.calls.append(('displacement', self.channel, value, time.monotonic()))
        self.first.set()


def plans(column, interval=10, length=3):
    return tuple({'channel': ch, 'path': Path(f'{column}_{ch + 1}.xlsx'),
                  'points': tuple(Point(str(i), str(column * 100 + ch * 10 + i), interval)
                                  for i in range(length))} for ch in (0, 1))


def targets(controller):
    return [call for call in controller.calls if call[0] in ('voltage', 'displacement')]


class GalvoTests(unittest.TestCase):
    def setUp(self):
        self.temp = tempfile.TemporaryDirectory()
        self.root = Path(self.temp.name)
        self.master = self.root / 'master.xlsx'
        for column in (1, 2):
            for channel in (1, 2):
                self.write(self.root / f'{column}_{channel}.xlsx',
                           [['发送数据', '数据间隔（毫秒）'], [column * 10 + channel, 10]])
        self.rows = [['序号', '1路', '2路'], [2, '2_1.xlsx', '2_2.xlsx'],
                     [None, None, None], [1, '1_1.xlsx', '1_2.xlsx']]
        self.write(self.master, self.rows)
        self.runner = None

    def tearDown(self):
        if self.runner:
            self.runner.abort()
            self.runner.stop_line()
        self.temp.cleanup()

    @staticmethod
    def write(path, rows):
        book = Workbook()
        for row in rows:
            book.active.append(row)
        book.save(path)
        book.close()

    def test_master_maps_by_number_not_row_order(self):
        columns = load_galvo_master(str(self.master), 2)
        self.assertEqual(columns[1][0]['points'][0].value, '11')
        self.assertEqual(columns[1][1]['points'][0].value, '12')
        self.assertEqual(columns[2][0]['points'][0].value, '21')
        self.assertEqual(columns[2][1]['points'][0].value, '22')

    def test_master_rejects_missing_duplicate_and_invalid_columns(self):
        with self.assertRaisesRegex(ValueError, '序号 3'):
            load_galvo_master(str(self.master), 3)
        for number in (1, 0, 'x', '=1+1', 1.2, True):
            self.write(self.master, self.rows + [[number, '1_1.xlsx', '1_2.xlsx']])
            with self.assertRaisesRegex(ValueError, '第 5 行'):
                load_galvo_master(str(self.master))

    def test_master_rejects_missing_files_and_invalid_points(self):
        (self.root / '2_2.xlsx').unlink()
        with self.assertRaisesRegex(ValueError, '第 2 行.*2路文件不存在'):
            load_galvo_master(str(self.master))
        self.write(self.root / '2_2.xlsx', [['发送数据', '数据间隔（毫秒）'], ['=1+1', 10]])
        with self.assertRaisesRegex(ValueError, '2路文件 2_2.xlsx'):
            load_galvo_master(str(self.master))

    def test_explicit_points_folder_is_used_instead_of_master_directory(self):
        folder = self.root / 'actual_points'
        folder.mkdir()
        for column in (1, 2):
            for channel in (1, 2):
                self.write(folder / f'{column}_{channel}.xlsx',
                           [['发送数据', '数据间隔（毫秒）'], [column * 100 + channel, 20]])
        columns = load_galvo_master(str(self.master), 2, str(folder))
        self.assertEqual(columns[1][0]['points'][0].value, '101')
        self.assertEqual(columns[2][1]['points'][0].value, '202')
        self.assertEqual(columns[1][0]['path'].parent, folder.resolve())
        self.assertEqual(load_galvo_master(str(self.master), 2)[1][0]['points'][0].value, '11')
        with self.assertRaisesRegex(ValueError, '点列文件夹不存在'):
            load_galvo_master(str(self.master), 2, str(folder / 'missing'))

    def test_runtime_reports_paths_first_targets_and_actual_counts(self):
        c = SerialStub(); messages = []
        self.runner = runner = GalvoScanRunner(c, {1: plans(1)}, [False, True], message=messages.append)
        runner.prepare_line(1); runner.start_line(1)
        runner._thread.join(1); runner.stop_line()
        self.assertEqual(runner.sent_counts(), {0: 3, 1: 3})
        self.assertTrue(any('1_1.xlsx' in m and '开环电压' in m for m in messages))
        self.assertTrue(any('1_2.xlsx' in m and '闭环位移' in m for m in messages))
        self.assertTrue(any('首点目标 100 已发送' in m for m in messages))
        self.assertTrue(any('1路已发送 3/3 点' in m and '2路已发送 3/3 点' in m for m in messages))

    def test_enabled_link_cannot_silently_run_without_loaded_point_lists(self):
        from main import UniformLineScanWorker
        with self.assertRaisesRegex(ValueError, '未加载有效'):
            UniformLineScanWorker(None, {'galvo_enabled': True}, {}, '', True)

    def test_master_caches_repeated_files(self):
        self.write(self.master, [['序号', '1路', '2路'], [1, '1_1.xlsx', '1_1.xlsx']])
        columns = load_galvo_master(str(self.master), 1)
        self.assertIs(columns[1][0]['points'], columns[1][1]['points'])

    def test_runner_prepares_before_start_and_uses_both_modes(self):
        c = SerialStub()
        self.runner = runner = GalvoScanRunner(c, {1: plans(1), 2: plans(2)}, [False, True])
        runner.prepare_line(1)
        self.assertEqual(targets(c), [])
        self.assertEqual([call[2] for call in c.calls if call[0] == 'mode'], ['open', 'closed'])
        runner.start_line(1)
        runner._thread.join(1)
        self.assertFalse(runner._thread.is_alive())
        first = targets(c)
        self.assertEqual(len(first), 6)
        self.assertEqual([call[2] for call in first if call[1] == 0], ['100', '101', '102'])
        self.assertTrue(all(call[0] == 'displacement' for call in first if call[1] == 1))
        runner.stop_line()
        runner.prepare_line(2)
        runner.start_line(2)
        runner._thread.join(1)
        runner.stop_line()
        self.assertEqual([call[2] for call in targets(c) if call[1] == 0],
                         ['100', '101', '102', '200', '201', '202'])
        self.assertTrue(runner.safe_to_release)

    def test_early_close_interrupts_long_interval_without_more_points(self):
        c = SerialStub()
        self.runner = runner = GalvoScanRunner(c, {1: plans(1, interval=60000)}, [False, False])
        runner.prepare_line(1)
        runner.start_line(1)
        self.assertTrue(c.first.wait(1))
        began = time.monotonic()
        runner.request_stop()
        runner.stop_line()
        self.assertLess(time.monotonic() - began, 0.5)
        count = len(targets(c))
        time.sleep(0.02)
        self.assertEqual(len(targets(c)), count)
        self.assertLessEqual(count, 2)
        self.assertEqual([call[1] for call in c.calls[-2:]], [0, 1])
        runner.abort()
        with self.assertRaises(RuntimeError): runner.start_line(1)
        with self.assertRaises(RuntimeError): runner.prepare_line(1)

    def test_bandwidth_preflight(self):
        c = SerialStub()
        with self.assertRaisesRegex(ValueError, '波特率'):
            GalvoScanRunner(c, {1: plans(1, interval=1)}, [False, False])
        self.assertEqual(c.calls, [])

    def test_serial_error_is_propagated(self):
        c = SerialStub()
        self.runner = runner = GalvoScanRunner(c, {1: plans(1)}, [False, False])
        runner.prepare_line(1)
        c.fail = True
        runner.start_line(1)
        runner._thread.join(1)
        with self.assertRaisesRegex(RuntimeError, 'test serial failure'):
            runner.raise_if_failed()
        runner.stop_line()
        self.assertTrue(runner.safe_to_release)

    def test_settings_roundtrip(self):
        w = GalvoScanSettings()
        config = {'galvo_enabled': True, 'galvo_master_excel': str(self.master),
                  'galvo_ch1_closed': True, 'galvo_ch2_closed': False, 'galvo_points_folder': ''}
        w.apply_config(config)
        self.assertEqual(w.config_values(), config)
        w.close()

    def test_worker_gates_targets_inside_each_shutter_open(self):
        from main import UniformLineScanWorker
        c = SerialStub()
        self.runner = runner = GalvoScanRunner(c, {1: plans(1), 2: plans(2)}, [False, False])
        from device_controllers import CH375ShutterClient
        gates = []
        class Shutter(CH375ShutterClient):
            def __init__(self, url): pass
            def write_command(self, command): gates.append(('open', time.monotonic()))
            def close_shutter(self): gates.append(('close', time.monotonic()))
        class Motion:
            position = {'X': 0, 'Y': 0}
            started = None
            halted = False
            def get_axis_status(self, axis): return type('Status', (), {'enabled': True})()
            def set_motion_parameters(self, *args): pass
            def move_absolute(self, axis, value):
                self.position[axis] = value
                if axis == 'Y': self.started = time.monotonic() if value == 1 else None
            def get_position(self, axis):
                if axis == 'Y' and self.started is not None:
                    return min(1, (time.monotonic() - self.started) / 0.15)
                return self.position[axis]
            def halt_all(self): self.halted = True
        v = {'x_start': 0, 'x_end': 1, 'x_step': 1, 'y_start': 0, 'y_end': 1,
             'uniform_shutter_position': 0.1, 'uniform_shutter_close_position': 0.9,
             'stable_ms': 0, 'speed': 1, 'uniform_shutters': [1, 2], '_galvo_runner': runner}
        worker = UniformLineScanWorker(Motion(), v, {'velocity': 1, 'acceleration': 1, 'deceleration': 1}, 'mock', False)
        errors = []
        worker.scanError.connect(errors.append)
        with patch('main.CH375ShutterClient', Shutter): worker.run()
        self.assertEqual(errors, [])
        self.assertEqual([g[0] for g in gates], ['open', 'close', 'open', 'close'])
        self.assertEqual(len(targets(c)), 12)
        for call in targets(c):
            column = int(call[2]) // 100
            self.assertGreaterEqual(call[3], gates[(column - 1) * 2][1])
            self.assertLess(call[3], gates[(column - 1) * 2 + 1][1])
        self.assertTrue(runner.safe_to_release)

    def test_worker_serial_failure_halts_motion_and_closes_shutter(self):
        from main import UniformLineScanWorker
        c = SerialStub()
        c.fail = True
        self.runner = runner = GalvoScanRunner(c, {1: plans(1)}, [False, False])
        class Motion:
            positions = {'X': 0, 'Y': 0}
            scanning = False
            halted = False
            def get_axis_status(self, axis): return type('Status', (), {'enabled': True})()
            def set_motion_parameters(self, *args): pass
            def move_absolute(self, axis, value):
                self.positions[axis] = value
                if axis == 'Y': self.scanning = value == 1
            def get_position(self, axis):
                return 0.5 if axis == 'Y' and self.scanning else self.positions[axis]
            def halt_all(self): self.halted = True
        motion = Motion()
        v = {'x_start': 0, 'x_end': 0, 'x_step': 1, 'y_start': 0, 'y_end': 1,
             'uniform_shutter_position': 0.1, 'uniform_shutter_close_position': 0.9,
             'stable_ms': 0, 'speed': 1, 'uniform_shutters': [1], '_galvo_runner': runner}
        worker = UniformLineScanWorker(motion, v, {'velocity': 1, 'acceleration': 1, 'deceleration': 1}, '', True)
        errors = []
        worker.scanError.connect(errors.append)
        worker.run()
        self.assertTrue(motion.halted)
        self.assertEqual(len(errors), 1)
        self.assertIn('test serial failure', errors[0])
        self.assertTrue(runner.safe_to_release)
        self.assertEqual(c.calls[-2][0:2], ('stop', 0))
        self.assertEqual(c.calls[-1][0:2], ('stop', 1))

    def test_worker_manual_stop_cancels_both_channels(self):
        from main import UniformLineScanWorker
        c = SerialStub()
        self.runner = runner = GalvoScanRunner(c, {1: plans(1, interval=60000)}, [False, False])
        class Motion:
            positions = {'X': 0, 'Y': 0}
            scanning = False
            halted = False
            worker = None
            def get_axis_status(self, axis): return type('Status', (), {'enabled': True})()
            def set_motion_parameters(self, *args): pass
            def move_absolute(self, axis, value):
                self.positions[axis] = value
                if axis == 'Y': self.scanning = value == 1
            def get_position(self, axis):
                if self.scanning and c.first.is_set(): self.worker.stop()
                return 0.5 if axis == 'Y' and self.scanning else self.positions[axis]
            def halt_all(self): self.halted = True
        motion = Motion()
        v = {'x_start': 0, 'x_end': 0, 'x_step': 1, 'y_start': 0, 'y_end': 1,
             'uniform_shutter_position': 0.1, 'uniform_shutter_close_position': 0.9,
             'stable_ms': 0, 'speed': 1, 'uniform_shutters': [1], '_galvo_runner': runner}
        motion.worker = worker = UniformLineScanWorker(motion, v, {'velocity': 1, 'acceleration': 1, 'deceleration': 1}, '', True)
        stopped = []; errors = []
        worker.scanStopped.connect(stopped.append)
        worker.scanError.connect(errors.append)
        worker.run()
        self.assertTrue(motion.halted)
        self.assertTrue(stopped)
        self.assertEqual(errors, [])
        self.assertTrue(runner.safe_to_release)
        self.assertLessEqual(len(targets(c)), 2)
        with self.assertRaises(RuntimeError): runner.prepare_line(1)
