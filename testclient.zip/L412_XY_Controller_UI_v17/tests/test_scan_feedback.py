import os
os.environ.setdefault('QT_QPA_PLATFORM', 'offscreen')
import threading
import time
import unittest
from unittest.mock import patch
from PyQt6.QtWidgets import QApplication
from serial_controller.scan_feedback import ScanFeedback
from serial_controller.custom_waveform import Point, play_points
from galvo_scan import GalvoScanRunner

app = QApplication.instance() or QApplication([])


class FeedbackController:
    timeout = 0.3
    connected = True

    def __init__(self):
        self.serial = type('Serial', (), {'baudrate': 115200, 'timeout': 0.05})()
        self.channel = 0
        self.values = {0: 0.0, 1: 0.0}
        self.targets = []
        self.reads = []
        self.reading = False
        self.fail = False
        self.first_read = threading.Event()

    def set_channel(self, channel):
        assert not self.reading, 'channel changed during query'
        self.channel = channel

    def set_mode(self, mode): pass
    def stop_waveform(self): assert not self.reading
    def disconnect(self): self.connected = False

    def set_voltage(self, value):
        assert not self.reading, 'point sent during query'
        self.values[self.channel] = float(value)
        self.targets.append((self.channel, float(value)))

    set_displacement = set_voltage

    def read_displacement(self):
        self.reading = True
        try:
            self.reads.append((self.channel, self.timeout, self.serial.timeout))
            time.sleep(0.002)
            self.first_read.set()
            if self.fail:
                raise TimeoutError('模拟位移回读超时')
            return self.values[self.channel] - 0.25
        finally:
            self.reading = False


def make_plans():
    return [{'channel': ch, 'closed': True,
             'points': [Point(str(i), str(ch * 10 + i), 25) for i in range(4)]}
            for ch in (0, 1)]


class FeedbackTests(unittest.TestCase):
    def test_rotation_targets_and_timeout_restoration(self):
        c = FeedbackController()
        rows = []
        f = ScanFeedback(rows.extend)
        f.configure(True, 100)
        f.begin({0: True, 1: False})
        f.target_sent(0, 5, True); c.values[0] = 5
        f.target_sent(1, 7, False); c.values[1] = 7
        with patch('serial_controller.scan_feedback.time.monotonic', return_value=100):
            self.assertTrue(f.step(c, (0, 1)))
        with patch('serial_controller.scan_feedback.time.monotonic', return_value=100.02):
            self.assertTrue(f.step(c, (0, 1)))
        with patch('serial_controller.scan_feedback.time.monotonic', return_value=100.06):
            self.assertFalse(f.step(c, (0, 1)))
        self.assertEqual([r['channel'] for r in rows], [0, 1])
        self.assertEqual(rows[0]['target'], 5)
        self.assertEqual(rows[0]['displacement'], 4.75)
        self.assertEqual(rows[0]['deviation'], -0.25)
        self.assertIsNone(rows[1]['deviation'])
        self.assertEqual(c.timeout, 0.3)
        self.assertEqual(c.serial.timeout, 0.05)
        self.assertTrue(all(query_timeout <= 0.03 and read_timeout <= 0.005
                            for _, query_timeout, read_timeout in c.reads))

    def test_manual_request_works_with_auto_off_and_is_coalesced(self):
        c = FeedbackController(); rows = []; f = ScanFeedback(rows.extend)
        f.configure(False, 1000); f.begin({0: True, 1: True})
        self.assertFalse(f.step(c, (0, 1)))
        f.request((0, 1)); f.request((0, 1))
        self.assertTrue(f.step(c, (0, 1)))
        self.assertTrue(f.step(c, (0, 1)))
        self.assertFalse(f.step(c, (0, 1)))
        self.assertEqual([r['channel'] for r in rows], [0, 1])
        f.request((0, 1))
        self.assertFalse(f.step(c, (0, 1), lambda: True))
        self.assertEqual(len(c.reads), 2)

    def test_failed_read_is_not_shown_as_measured_zero(self):
        c = FeedbackController(); c.fail = True
        rows = []; f = ScanFeedback(rows.extend)
        f.begin({0: True}); f.target_sent(0, 3, True)
        self.assertTrue(f.step(c, (0,)))
        self.assertIsNone(rows[0]['displacement'])
        self.assertIsNone(rows[0]['deviation'])
        self.assertIn('超时', rows[0]['errors'][0])
        self.assertEqual(c.timeout, 0.3)
        self.assertEqual(c.serial.timeout, 0.05)

    def test_manual_dual_channel_playback_reads_without_reordering_targets(self):
        c = FeedbackController(); rows = []; f = ScanFeedback(rows.extend)
        f.configure(True, 50)
        plans = make_plans()
        cancelled = {ch: threading.Event() for ch in (0, 1)}
        play_points(c, plans, cancelled, lambda *args: None, feedback=f)
        self.assertEqual(len(c.targets), 8)
        for ch in (0, 1):
            self.assertEqual([value for channel, value in c.targets if channel == ch],
                             [float(ch * 10 + i) for i in range(4)])
        self.assertEqual({r['channel'] for r in rows}, {0, 1})
        self.assertTrue(all(r['deviation'] == -0.25 for r in rows))
        self.assertEqual(c.timeout, 0.3)

    def test_shutter_gated_playback_reads_even_after_last_point_until_close(self):
        c = FeedbackController(); rows = []; f = ScanFeedback(rows.extend)
        f.configure(True, 50)
        runner = GalvoScanRunner(c, {1: make_plans()}, [True, True], feedback=f)
        try:
            runner.prepare_line(1); runner.start_line(1)
            self.assertTrue(c.first_read.wait(1))
            deadline = time.monotonic() + 1
            while len(c.targets) < 8 and time.monotonic() < deadline: time.sleep(0.005)
            self.assertEqual(len(c.targets), 8)
            reads = len(c.reads)
            deadline = time.monotonic() + 0.3
            while len(c.reads) <= reads and time.monotonic() < deadline: time.sleep(0.005)
            self.assertGreater(len(c.reads), reads)
            self.assertTrue(runner._thread.is_alive())
            runner.request_stop(); runner.stop_line()
            reads = len(c.reads); writes = len(c.targets)
            time.sleep(0.03)
            self.assertEqual(len(c.reads), reads)
            self.assertEqual(len(c.targets), writes)
            self.assertEqual({r['channel'] for r in rows}, {0, 1})
            self.assertTrue(runner.safe_to_release)
            self.assertEqual(c.timeout, 0.3)
        finally:
            runner.abort(); runner.stop_line()

    def test_ui_reads_remain_enabled_without_unlocking_motion_controls(self):
        from serial_controller.serial_gui import Window
        window = Window()
        try:
            window.auto.setChecked(False)
            window.worker.controller = FeedbackController()
            window.online = True
            window.reserve_for_scan()
            self.assertTrue(window.refresh_button.isEnabled())
            self.assertFalse(window.controls.isEnabled())
            self.assertFalse(window.connect_button.isEnabled())
            window.worker.feedback.begin({0: True, 1: True})
            window.refresh()
            self.assertTrue(window.busy)
            self.assertTrue(window.scan_reserved)
            rows = []
            window.worker.feedback.emit = rows.extend
            window.worker.feedback.target_sent(0, 2, True)
            window.worker.controller.values[0] = 2
            window.worker.feedback.step(window.worker.controller, (0, 1))
            window.display_feedback(rows)
            self.assertEqual(window.table.item(0, 3).text(), '1.7500')
            self.assertEqual(window.table.item(0, 4).text(), '2.0000 位移')
            self.assertEqual(window.table.item(0, 5).text(), '-0.2500')
            self.assertIn('扫描中位移反馈', window.table.item(0, 7).text())
            window.release_from_scan()
            self.assertFalse(window.busy)
        finally:
            window.online = False
            window.close()
            deadline = time.monotonic() + 2
            while window.thread.isRunning() and time.monotonic() < deadline:
                app.processEvents(); time.sleep(0.001)
            self.assertFalse(window.thread.isRunning())
