from pathlib import Path
import sys

ROOT = Path(__file__).resolve().parent
REQUIRED = [
    "main.py",
    "device_controllers.py",
    "styles.qss",
    "shutter32_server.py",
    "diagnose_ch375_32.py",
    "requirements.txt",
    "start_main64.bat",
    "start_shutter32.bat",
    "start_shutter32_simulate.bat",
    "diagnose_ch375_32.bat",
    "README.md",
]

missing = [name for name in REQUIRED if not (ROOT / name).is_file()]
print("Project:", ROOT)
for name in REQUIRED:
    print(("[OK]      " if (ROOT / name).is_file() else "[MISSING] ") + name)

print("[OPTIONAL] CH375DLL.DLL:", "present" if (ROOT / "CH375DLL.DLL").is_file() else "not included; copy your 32-bit DLL here")

if missing:
    print("\nMissing files:")
    for name in missing:
        print(" -", name)
    raise SystemExit(1)

print("\nProject file check passed.")
raise SystemExit(0)
