@echo off
setlocal
cd /d "%~dp0"

rem ===== 修改为你的 64 位 Python 路径 =====
set "PYTHON64=C:\Python311\python.exe"

if not exist "%PYTHON64%" (
    echo [ERROR] 64-bit Python not found:
    echo %PYTHON64%
    echo Please edit start_main64.bat and set PYTHON64 correctly.
    pause
    exit /b 1
)

"%PYTHON64%" -c "import struct,sys; bits=struct.calcsize('P')*8; print('Python:',sys.executable); print('Bits:',bits); raise SystemExit(0 if bits==64 else 2)"
if errorlevel 1 (
    echo [ERROR] Main program must use 64-bit Python.
    pause
    exit /b 1
)

"%PYTHON64%" main.py
if errorlevel 1 pause
endlocal
