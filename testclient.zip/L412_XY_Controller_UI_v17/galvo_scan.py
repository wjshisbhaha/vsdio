"""Per-column dual-channel galvo point lists gated by uniform-scan shutters."""
from pathlib import Path
import math
import threading
import time
from openpyxl import load_workbook
from PyQt6.QtCore import pyqtSignal
from PyQt6.QtWidgets import (QWidget, QVBoxLayout, QHBoxLayout, QCheckBox,
                            QLabel, QLineEdit, QPushButton, QFileDialog, QMessageBox)
from serial_controller.custom_waveform import load_points


def load_galvo_master(filename, count=None, folder=""):
    """序号 -> CH1/CH2 point lists, using an explicit folder or master directory."""
    path = Path(filename).expanduser()
    if not filename or not path.is_file():
        raise ValueError('请选择有效的振镜移动总表 Excel。')
    base = Path(folder).expanduser().resolve() if folder.strip() else path.parent.resolve()
    if not base.is_dir():
        raise ValueError(f'振镜点列文件夹不存在：{base}')
    workbook = load_workbook(path, read_only=True, data_only=False)
    columns = {}
    cache = {}
    try:
        rows = iter(enumerate(workbook.worksheets[0].iter_rows(values_only=True), 1))
        blank = lambda row: all(v is None or str(v).strip() == '' for v in row)
        first = next((row for _, row in rows if not blank(row)), None)
        if first is None:
            raise ValueError('振镜总表为空。')
        header = [str(v).strip() for v in first]
        required = ('序号', '1路', '2路')
        for name in required:
            if header.count(name) != 1:
                raise ValueError(f'振镜总表必须包含且仅包含一个“{name}”字段。')
        indices = [header.index(name) for name in required]
        for row_number, row in rows:
            if blank(row):
                continue
            try:
                number, *files = [row[i] if i < len(row) else None for i in indices]
                number_value = float(number)
                if isinstance(number, bool) or not math.isfinite(number_value) or number_value < 1 or not number_value.is_integer():
                    raise ValueError('序号必须为正整数，对应扫描列号')
                column = int(number_value)
                if column in columns:
                    raise ValueError(f'序号 {column} 重复')
                plans = []
                for channel, filename_value in enumerate(files):
                    if filename_value is None or not str(filename_value).strip() or str(filename_value).startswith('='):
                        raise ValueError(f'{channel + 1}路文件名不能为空，不支持公式')
                    point_path = Path(str(filename_value).strip()).expanduser()
                    point_path = (point_path if point_path.is_absolute() else base / point_path).resolve()
                    if not point_path.is_file():
                        raise ValueError(f'{channel + 1}路文件不存在：{point_path}；请检查振镜点列文件夹及总表文件名')
                    if point_path not in cache:
                        try:
                            cache[point_path] = tuple(load_points(point_path))
                        except Exception as exc:
                            raise ValueError(f'{channel + 1}路文件 {point_path.name}：{exc}') from exc
                    plans.append({'channel': channel, 'path': point_path, 'points': cache[point_path]})
                columns[column] = tuple(plans)
            except (ValueError, TypeError) as exc:
                raise ValueError(f'振镜总表第 {row_number} 行：{exc}') from exc
    finally:
        workbook.close()
    if not columns:
        raise ValueError('振镜总表没有有效记录。')
    if count is not None:
        for column in range(1, count + 1):
            if column not in columns:
                raise ValueError(f'第 {column} 条扫描线缺少振镜总表序号 {column}。')
    return columns


class GalvoScanSettings(QWidget):
    changed = pyqtSignal()

    def __init__(self, parent=None):
        super().__init__(parent)
        box = QVBoxLayout(self)
        box.setContentsMargins(0, 0, 0, 0)
        self.enabled = QCheckBox('匀速扫描联动振镜（随扫描快门启动/停止）')
        box.addWidget(self.enabled)
        box.addWidget(QLabel('振镜移动总表 Excel（序号、1路、2路）'))
        row = QHBoxLayout()
        self.master = QLineEdit()
        self.master.setPlaceholderText('选择序号、1路、2路的映射总表')
        choose = QPushButton('选择')
        choose.setFixedWidth(66)
        choose.clicked.connect(self.choose_master)
        row.addWidget(self.master, 1)
        row.addWidget(choose)
        box.addLayout(row)
        box.addWidget(QLabel('振镜点列文件夹（留空使用总表所在目录）'))
        folder_row = QHBoxLayout()
        self.folder = QLineEdit()
        self.folder.setPlaceholderText('1路/2路点列 Excel 实际所在文件夹')
        choose_folder = QPushButton('选择')
        choose_folder.setFixedWidth(66)
        choose_folder.clicked.connect(self.choose_folder)
        folder_row.addWidget(self.folder, 1)
        folder_row.addWidget(choose_folder)
        box.addLayout(folder_row)
        self.closed = [QCheckBox('1路闭环（位移）'), QCheckBox('2路闭环（位移）')]
        modes = QHBoxLayout()
        for widget in self.closed:
            modes.addWidget(widget)
            widget.toggled.connect(self.changed)
        box.addLayout(modes)
        read = QPushButton('读取并检查振镜总表')
        read.clicked.connect(self.read_master)
        box.addWidget(read)
        self.status = QLabel('尚未读取振镜总表')
        self.status.setWordWrap(True)
        box.addWidget(self.status)
        note = QLabel('第k条扫描线使用序号k的1路/2路文件；点列读取各文件第一张工作表。\n'
                      '点列表头：发送数据、数据间隔（毫秒）；未勾选闭环时为开环电压。\n'
                      '请先在振镜控制页连接串口，至少启用2个通道。\n'
                      '每列开快门后两路共用起点、串口依次发送；关门立即取消后续点。\n'
                      '点列播放一次，播完保留最后目标值，不循环、不归零。')
        note.setWordWrap(True)
        box.addWidget(note)
        self.enabled.toggled.connect(self.changed)
        self.master.textChanged.connect(self.invalidate)
        self.folder.textChanged.connect(self.invalidate)

    def invalidate(self):
        self.status.setText('文件地址已更改，请重新读取；开始扫描时会再次检查')
        self.changed.emit()

    def choose_master(self):
        path, _ = QFileDialog.getOpenFileName(self, '选择振镜移动总表', self.master.text(), 'Excel (*.xlsx *.xlsm)')
        if path:
            self.master.setText(path)

    def choose_folder(self):
        folder = QFileDialog.getExistingDirectory(self, '选择振镜点列文件夹', self.folder.text())
        if folder:
            self.folder.setText(folder)

    def read_master(self):
        try:
            columns = load_galvo_master(self.master.text().strip(), folder=self.folder.text().strip())
            detail = '\n'.join(f"序号{k}：\n1路 {plans[0]['path']}（{len(plans[0]['points'])}点）\n"
                               f"2路 {plans[1]['path']}（{len(plans[1]['points'])}点）"
                               for k, plans in sorted(columns.items()))
            self.status.setText(f'已读取 {len(columns)} 列，两路点列检查通过')
            self.status.setToolTip(detail)
            QMessageBox.information(self, '振镜总表检查通过', detail)
        except Exception as exc:
            self.status.setText('读取失败：' + str(exc))
            QMessageBox.warning(self, '振镜总表读取失败', str(exc))

    def config_values(self):
        return {'galvo_enabled': self.enabled.isChecked(), 'galvo_master_excel': self.master.text().strip(),
                'galvo_points_folder': self.folder.text().strip(),
                'galvo_ch1_closed': self.closed[0].isChecked(), 'galvo_ch2_closed': self.closed[1].isChecked()}

    def apply_config(self, config):
        self.enabled.setChecked(bool(config.get('galvo_enabled', False)))
        self.master.setText(str(config.get('galvo_master_excel', '')))
        self.folder.setText(str(config.get('galvo_points_folder', '')))
        for i, widget in enumerate(self.closed, 1):
            widget.setChecked(bool(config.get(f'galvo_ch{i}_closed', False)))


class GalvoScanRunner:
    """Exclusive serial ownership, prepared before Y motion, gated point sending.

    The scan worker configures/stops hardware; only the playback thread sends
    targets during an exposure. Cancellation is independent of the Qt event loop.
    """
    def __init__(self, controller, columns, closed_modes, feedback=None, message=None):
        self.controller = controller
        self.feedback = feedback
        self.message = message
        self._stats_lock = threading.Lock()
        self._sent = {0: 0, 1: 0}
        self._report_pending = False
        self.columns = columns
        self.closed_modes = tuple(closed_modes)
        self._lock = threading.RLock()
        self._cancel = threading.Event()
        self._aborted = threading.Event()
        self._thread = None
        self._error = None
        self._column = None
        self._needs_stop = False
        baud = controller.serial.baudrate
        for column, plans in columns.items():
            load = sum(110 / baud / (min(p.interval_ms for p in plan['points']) / 1000) for plan in plans)
            if load > 0.8:
                raise ValueError(f'振镜总表序号 {column} 点列间隔过短，超过当前波特率可用带宽。')

    def _log(self, text):
        if self.message is not None:
            self.message(text)

    def sent_counts(self):
        with self._stats_lock:
            return dict(self._sent)

    @property
    def safe_to_release(self):
        # No sender may survive a transfer back to the manual SC20 controls.
        # Failed stop commands are reported, but an idle port remains recoverable.
        return not (self._thread and self._thread.is_alive())

    def request_stop(self):
        self._cancel.set()

    def abort(self):
        self._aborted.set()
        self.request_stop()

    def raise_if_failed(self):
        if self._error is not None:
            raise RuntimeError('振镜点列发送失败：' + str(self._error)) from self._error

    def prepare_line(self, column):
        with self._lock:
            self.stop_line()
            self.raise_if_failed()
            if self._aborted.is_set():
                raise RuntimeError('振镜联动已停止')
            self._column = column
            with self._stats_lock:
                self._sent = {0: 0, 1: 0}
            if self.feedback is not None:
                self.feedback.begin(dict(enumerate(self.closed_modes)))
            self._cancel.clear()
            self._needs_stop = True
            for plan in self.columns[column]:
                if self._aborted.is_set():
                    raise RuntimeError('振镜联动已停止')
                self.controller.set_channel(plan['channel'])
                self.controller.stop_waveform()
                self.controller.set_mode('closed' if self.closed_modes[plan['channel']] else 'open')
                mode = '闭环位移' if self.closed_modes[plan['channel']] else '开环电压'
                self._log(f"振镜第{column}列 {plan['channel'] + 1}路：{plan.get('path', '内存点列')}，{len(plan['points'])}点，{mode}，已准备。")

    def start_line(self, column):
        with self._lock:
            self.raise_if_failed()
            if self._aborted.is_set() or self._cancel.is_set():
                raise RuntimeError('振镜联动已停止')
            if column != self._column:
                raise RuntimeError('振镜当前列尚未准备')
            if self._thread and self._thread.is_alive():
                raise RuntimeError('上一列振镜点列仍在运行')
            self._report_pending = True
            self._log(f'振镜第{column}列：开快门指令完成，开始发送两路点列。')
            epoch = time.monotonic()
            self._thread = threading.Thread(target=self._play, args=(column, epoch), daemon=True,
                                            name=f'galvo-column-{column}')
            self._thread.start()

    def _play(self, column, epoch):
        try:
            active = {plan['channel']: {'plan': plan, 'index': 0, 'due': epoch}
                      for plan in self.columns[column]}
            while not self._cancel.is_set():
                if not active:
                    if self.feedback is None:
                        break
                    if not self.feedback.step(self.controller, (0, 1), self._cancel.is_set):
                        self._cancel.wait(0.01)
                    continue
                channel = min(active, key=lambda c: active[c]['due'])
                state = active[channel]
                delay = state['due'] - time.monotonic()
                if delay > 0:
                    if self.feedback is not None and self.feedback.step(self.controller, (0, 1), self._cancel.is_set):
                        continue
                    self._cancel.wait(min(delay, 0.01))
                    continue
                if self._cancel.is_set():
                    break
                point = state['plan']['points'][state['index']]
                self.controller.set_channel(channel)
                if self._cancel.is_set():
                    break
                send = self.controller.set_displacement if self.closed_modes[channel] else self.controller.set_voltage
                send(point.value)
                with self._stats_lock:
                    self._sent[channel] += 1
                if state['index'] == 0:
                    self._log(f'振镜第{column}列 {channel + 1}路：首点目标 {point.value} 已发送。')
                if self.feedback is not None:
                    self.feedback.target_sent(channel, point.value, self.closed_modes[channel])
                state['index'] += 1
                if state['index'] == len(state['plan']['points']):
                    self._log(f"振镜第{column}列 {channel + 1}路：{state['index']}点发送完成，保持最后目标。")
                    del active[channel]
                else:
                    state['due'] = time.monotonic() + point.interval_ms / 1000
        except Exception as exc:
            self._error = exc
            self._cancel.set()
            self._log(f'振镜第{column}列发送失败：{exc}')

    def stop_line(self):
        self.request_stop()
        with self._lock:
            if self._thread:
                self._thread.join(timeout=max(1.0, self.controller.timeout * 4 + 0.2))
                if self._thread.is_alive():
                    raise RuntimeError('振镜发送线程未停止，串口仍被联动任务占用')
            if self._report_pending:
                counts = self.sent_counts()
                totals = {p['channel']: len(p['points']) for p in self.columns[self._column]}
                self._log(f"振镜第{self._column}列停止：1路已发送 {counts[0]}/{totals[0]} 点，"
                          f"2路已发送 {counts[1]}/{totals[1]} 点。")
                if not any(counts.values()):
                    self._log('振镜本列未发送任何点，请检查快门开关位置是否相同或开门窗口是否过短。')
                self._report_pending = False
            if not self._needs_stop:
                return
            errors = []
            for channel in (0, 1):
                try:
                    self.controller.set_channel(channel)
                    self.controller.stop_waveform()
                except Exception as exc:
                    errors.append(str(exc))
            if errors:
                raise RuntimeError('振镜停止指令失败：' + '；'.join(errors))
            self._needs_stop = False
