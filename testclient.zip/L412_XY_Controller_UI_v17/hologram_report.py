"""Export a verifiable software-side hologram timing audit (not optical metrology)."""
from datetime import datetime
from pathlib import Path
import os
from uuid import uuid4
from openpyxl import Workbook
from openpyxl.styles import Font, PatternFill, Alignment
from openpyxl.utils import get_column_letter


def export_report(player, status):
    entries = player.report_entries
    events = player.timeline.history()
    opens = [(generation, stamp) for generation, opened, stamp in events if opened]
    shown = {(row['generation'], row['index']): row for row in player.records}
    workbook = Workbook()
    summary = workbook.active; summary.title = '运行摘要'
    details = workbook.create_sheet('图片切换记录')
    gates = workbook.create_sheet('快门时序')
    def wall(stamp):
        return datetime.fromtimestamp(player.wall_origin + stamp - player.clock_origin).isoformat(timespec='milliseconds')
    def append(sheet, values):
        sheet.append(values)
        # Names and annotations from the input workbook are text, never formulas.
        for cell in sheet[sheet.max_row]:
            if isinstance(cell.value, str): cell.data_type = 's'
    headers = ['开门轮次','图片序号','源Excel行','空行分组','相位图名称','m标注','列号n(Y向)',
               '计划相对开门(ms)','实际相对开门(ms)','计划间隔(ms)','实际间隔(ms)',
               '设定频率(Hz)','实际频率(Hz)','绝对时刻迟到(ms)','间隔误差(ms)',
               '绘制迟到<16ms','间隔误差绝对值<16ms','记录状态','软件绘制完成时间',
               '扫描类型','扫描序号','目标X(mm)','目标Y(mm)',
               '最近反馈X(mm)','最近反馈Y(mm)','X反馈距切图(ms)','Y反馈距切图(ms)',
               'X读取耗时(ms)','Y读取耗时(ms)','图片路径']
    append(details, headers)
    planned_total = 0
    for cycle, (generation, started) in enumerate(opens, 1):
        indices, offsets = player.sequence_for(generation)
        planned_total += len(indices)
        previous = None
        closed = next((stamp for gen, is_open, stamp in events if gen > generation and not is_open), None)
        for index, global_index in enumerate(indices):
            entry = entries[global_index]
            record = shown.get((generation,global_index))
            planned_interval = (offsets[index] - offsets[index-1]) * 1000 if index else None
            requested_hz = 1000 / planned_interval if planned_interval else None
            actual_interval = ((record['stamp'] - previous['stamp']) * 1000
                               if record is not None and previous is not None else None)
            actual_hz = 1000 / actual_interval if actual_interval and actual_interval > 0 else None
            interval_error = actual_interval - planned_interval if actual_interval is not None else None
            context = record.get('context', {}) if record else player.timeline.context(generation)
            feedback = record.get('feedback', {}) if record else {}
            pos = []; age = []; duration = []
            for axis in ('X','Y'):
                item = feedback.get(axis)
                pos.append(item['position'] if item else None)
                age.append((record['stamp'] - item['ended']) * 1000 if item else None)
                duration.append((item['ended'] - item['began']) * 1000 if item else None)
            if record:
                state = '已调用绘制'
            elif closed is not None and closed <= started + offsets[index]:
                state = '未切换：已关闭快门'
            else:
                state = '未切换：停止/结束/界面未及时处理'
            append(details, [cycle,index+1,entry.excel_row,entry.group+1,entry.path.name,
                '' if entry.m is None else str(entry.m),'' if entry.n is None else str(entry.n),
                offsets[index]*1000, (record['stamp']-started)*1000 if record else None,
                planned_interval,actual_interval,requested_hz,actual_hz,
                record['late_ms'] if record else None,interval_error,
                ('是' if record['late_ms'] < 16 else '否') if record else '未验证',
                ('是' if abs(interval_error)<16 else '否') if interval_error is not None else '不适用',
                state,wall(record['stamp']) if record else None,
                context.get('kind'),context.get('index'),context.get('x'),context.get('y'),
                *pos,*age,*duration,str(entry.path)])
            previous = record
    append(gates,['事件序号','动作','软件时间','单调时钟(s)'])
    for generation, opened, stamp in events:
        append(gates,[generation,'开门指令完成' if opened else '请求关门',wall(stamp),stamp])
    worst = max((r['late_ms'] for r in player.records),default=None)
    append(summary,['项目','值'])
    for key,value in [
        ('运行结果',status),('导出时间',datetime.now().isoformat(timespec='seconds')),
        ('全息图Excel',player.report_config.get('hologram_excel','')),
        ('扫描模式',player.report_config.get('mode','')),
        ('设定频率Hz',player.report_config.get('hologram_frequencies','')),
        ('启动延迟ms',player.report_config.get('hologram_delay_ms',0)),
        ('图片记录数',len(entries)),('开门次数',len(opens)),('计划显示总次数',planned_total),
        ('已调用绘制次数',len(player.records)),('未切换次数',planned_total-len(player.records)),
        ('最大软件绘制迟到ms',worst),('绘制迟到≥16ms次数',sum(r['late_ms']>=16 for r in player.records)),
        ('未及时处理的快门状态变化',player.missed),
        ('计时定义','开门起点为软件收到开门指令完成响应；实际时间为repaint返回时间，并非显示器出光时间。'),
        ('频率定义','设定/实际频率对应从上一张到本张的间隔；每轮第一张无切换频率，只有启动延迟。'),
        ('位置定义','X/Y为切换前最近一次独立采样反馈；两轴非同步。距切图时间及读取耗时列用于评估位置可信度，空白表示无反馈。'),
        ('采样间隔','沿用现有位置轮询（通常200ms），切图时不执行阻塞式硬件读取。'),
        ('行列标注','匀速扫描第k条使用列号n=k，每列内按源Excel顺序播放；m仅供查看，不参与坐标匹配。'),
        ('验收范围','仅软件侧核对；小于16ms的实际画面及真实位置同步需硬件触发/光学测量验证。')]:
        append(summary,[key,value])
    for sheet in workbook:
        sheet.freeze_panes='A2';sheet.auto_filter.ref=sheet.dimensions
        for cell in sheet[1]:
            cell.font=Font(bold=True,color='FFFFFF');cell.fill=PatternFill('solid',fgColor='24568A')
        for row in sheet.iter_rows(min_row=2):
            for cell in row:
                cell.alignment=Alignment(vertical='top',wrap_text=True)
                if isinstance(cell.value,float):cell.number_format='0.000'
        for col in range(1,sheet.max_column+1):
            sheet.column_dimensions[get_column_letter(col)].width=22
    summary.column_dimensions['B'].width=100
    details.column_dimensions['AD'].width=65
    destination=Path(player.report_directory)
    destination.mkdir(parents=True,exist_ok=True)
    name='全息图切换记录_'+datetime.now().strftime('%Y%m%d_%H%M%S_%f')+'_'+uuid4().hex[:6]+'.xlsx'
    output=destination/name
    temporary=destination/('.'+name+'.tmp')
    try:
        workbook.save(temporary)
        os.replace(temporary,output)
    finally:
        workbook.close()
        if temporary.exists():temporary.unlink()
    return output
