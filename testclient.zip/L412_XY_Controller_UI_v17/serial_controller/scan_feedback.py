"""Cooperative position reads performed by the current point-list serial owner.

There is never a second serial reader. One bounded query is inserted between
outgoing point packets; both channels receive their own timestamp and target.
"""
import threading
import time
from datetime import datetime


class ScanFeedback:
    def __init__(self, emit):
        self.emit = emit
        self._lock = threading.Lock()
        self._enabled = True
        self._interval = 1.0
        self._query_timeout = 0.03
        self._pending = set()
        self._modes = {}
        self._targets = {}
        self._next = 0.0
        self._cursor = 0

    def configure(self, enabled, interval_ms, timeout_ms=30):
        with self._lock:
            self._enabled = bool(enabled)
            self._interval = max(0.05, float(interval_ms) / 1000)
            self._query_timeout = max(0.005, float(timeout_ms) / 1000)
            self._next = 0.0

    def begin(self, modes):
        with self._lock:
            self._modes = dict(modes)
            self._targets = {}
            # Read every participating channel on the first available gaps;
            # short scan columns must not repeatedly sample only channel 1.
            self._pending = set(modes) if self._enabled else set()
            self._next = 0.0
            self._cursor = 0

    def request(self, channels):
        with self._lock:
            self._pending.update(channels)

    def target_sent(self, channel, value, closed):
        with self._lock:
            self._targets[channel] = {'target': float(value), 'closed': bool(closed)}

    def step(self, controller, channels, cancelled=lambda: False):
        """Run at most one query; owner must service due targets before calling.

        A read may delay the next target. Timeout bounds the wait for a response,
        not operating-system/USB scheduling. Cancellation suppresses queued reads.
        """
        if cancelled():
            return False
        channels = tuple(channels)
        if not channels:
            return False
        now = time.monotonic()
        with self._lock:
            requested = self._pending.intersection(channels)
            if requested:
                channel = min(requested)
                self._pending.remove(channel)
            elif self._enabled and now >= self._next:
                channel = channels[self._cursor % len(channels)]
                self._cursor += 1
            else:
                return False
            query_timeout = self._query_timeout
            closed = self._modes.get(channel, False)
            target = dict(self._targets.get(channel, {}))
            self._next = now + self._interval / len(channels)
        if cancelled():
            return False
        # One request (7 bytes) and response (11 bytes), plus device turnaround.
        budget = min(controller.timeout, max(query_timeout, 180 / controller.serial.baudrate + 0.005))
        old_timeout = controller.timeout
        old_read_timeout = controller.serial.timeout
        row = {'channel': channel, 'mode': 'closed' if closed else 'open',
               'errors': [], 'scan_feedback': True, **target}
        began = time.monotonic()
        try:
            controller.timeout = budget
            controller.serial.timeout = min(0.005, budget)
            controller.set_channel(channel)
            if cancelled():
                return False
            row['displacement'] = controller.read_displacement()
        except Exception as exc:
            row['displacement'] = None
            row['errors'].append(str(exc))
        finally:
            controller.timeout = old_timeout
            controller.serial.timeout = old_read_timeout
        row['sampled_at'] = datetime.now().strftime('%H:%M:%S.%f')[:-3]
        row['read_ms'] = (time.monotonic() - began) * 1000
        row['deviation'] = (row['displacement'] - row['target']
                            if closed and row['displacement'] is not None and 'target' in row else None)
        self.emit([row])
        return True
