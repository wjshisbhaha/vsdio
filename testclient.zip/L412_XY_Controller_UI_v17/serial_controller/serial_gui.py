"""中文多通道串口控制台：python serial_gui.py。"""
import sys
import threading
from datetime import datetime
from PyQt6 import QtCore, QtWidgets
from serial.tools import list_ports
if __package__:
    from .serial_controller import SerialController
    from .custom_waveform import play_points
    from .scan_feedback import ScanFeedback
    from .custom_waveform_ui import CustomWaveformWidget
else:
    from serial_controller import SerialController
    from custom_waveform import play_points
    from scan_feedback import ScanFeedback
    from custom_waveform_ui import CustomWaveformWidget


class Worker(QtCore.QObject):
    done = QtCore.pyqtSignal(str, object, str)
    progress = QtCore.pyqtSignal(int, int, int, str)
    feedbackReady = QtCore.pyqtSignal(object)

    def __init__(self):
        super().__init__()
        self.controller = SerialController(timeout=0.3)
        self.feedback = ScanFeedback(self.feedbackReady.emit)
        self.cancelled = {0: threading.Event(), 1: threading.Event()}

    @QtCore.pyqtSlot(str, object)
    def execute(self, action, args):
        c = self.controller
        result = None
        error = ''
        try:
            if action == 'connect':
                c.address = args['address']
                c.connect(args['port'], args['baud'])
            elif action == 'disconnect':
                c.disconnect()
            elif action == 'play':
                play_points(c, args['plans'], self.cancelled, self.progress.emit, feedback=self.feedback)
            elif action == 'refresh':
                result = []
                for channel in range(args['count']):
                    c.set_channel(channel)
                    row = {'channel': channel, 'errors': []}
                    for field, method in [('mode', c.read_mode), ('voltage', c.read_voltage), ('displacement', c.read_displacement)]:
                        try:
                            row[field] = method()
                        except Exception as exc:
                            row[field] = None
                            row['errors'].append(str(exc))
                    result.append(row)
            else:
                c.set_channel(args['channel'])
                if action == 'mode':
                    result = c.set_mode(args['mode'])
                elif action in ('target', 'wave'):
                    expected = 'open' if args['output'] == 'voltage' else 'closed'
                    if c.read_mode() != expected:
                        raise ValueError('模式不匹配：电压输出请先设置开环，位移输出请先设置闭环')
                    if action == 'target':
                        (c.set_voltage if expected == 'open' else c.set_displacement)(args['value'])
                    else:
                        c.start_waveform(args['kind'], args['output'], args['peak'], args['frequency'], args['offset'])
                elif action == 'stop':
                    c.stop_waveform()
        except Exception as exc:
            error = str(exc)
        self.done.emit(action, result, error)


class Window(QtWidgets.QMainWindow):
    request = QtCore.pyqtSignal(str, object)
    shutdownFinished = QtCore.pyqtSignal()

    def __init__(self, parent=None):
        super().__init__(parent)
        if parent is not None:
            self.setWindowFlags(QtCore.Qt.WindowType.Widget)
        self.setWindowTitle('多通道串口控制台')
        self.resize(1040, 800)
        self.online = False
        self.busy = False
        self.closing = False
        self.scan_reserved = False
        self.playing_points = False
        self.thread = QtCore.QThread(self)
        self.worker = Worker()
        self.worker.moveToThread(self.thread)
        self.request.connect(self.worker.execute)
        self.worker.done.connect(self.completed)
        self.worker.feedbackReady.connect(self.display_feedback)
        self.thread.finished.connect(self.worker.deleteLater)
        self.thread.finished.connect(self.shutdownFinished)
        self.thread.finished.connect(self.close)
        self.thread.start()
        root = QtWidgets.QWidget()
        self.setCentralWidget(root)
        layout = QtWidgets.QVBoxLayout(root)
        title = QtWidgets.QLabel('多通道控制台')
        title.setStyleSheet('font-size:24px;font-weight:600')
        layout.addWidget(title)
        self.connection = QtWidgets.QGroupBox('设备连接')
        line = QtWidgets.QHBoxLayout(self.connection)
        self.port = QtWidgets.QComboBox(); self.port.setEditable(True); self.port.setMinimumWidth(200)
        self.baud = QtWidgets.QComboBox(); self.baud.addItems(['115200', '9600', '19200', '38400', '57600', '230400', '460800', '921600'])
        self.address = QtWidgets.QSpinBox(); self.address.setRange(0, 255); self.address.setValue(1)
        self.count = QtWidgets.QSpinBox(); self.count.setRange(1, 16); self.count.setValue(3)
        self.scan = QtWidgets.QPushButton('刷新串口'); self.scan.clicked.connect(self.scan_ports)
        self.connect_button = QtWidgets.QPushButton('连接'); self.connect_button.clicked.connect(self.toggle_connection)
        for label, widget in [('串口', self.port), ('波特率', self.baud), ('地址', self.address), ('通道数', self.count)]:
            line.addWidget(QtWidgets.QLabel(label)); line.addWidget(widget)
        line.addWidget(self.scan); line.addWidget(self.connect_button)
        layout.addWidget(self.connection)
        self.state = QtWidgets.QLabel('未连接')
        layout.addWidget(self.state)
        bar = QtWidgets.QHBoxLayout()
        bar.addWidget(QtWidgets.QLabel('各通道反馈 · 界面 CH1 对应协议通道 0'))
        bar.addStretch()
        self.auto = QtWidgets.QCheckBox('自动刷新')
        self.auto.setChecked(True)
        bar.addWidget(self.auto)
        bar.addWidget(QtWidgets.QLabel('读取间隔'))
        self.read_interval = QtWidgets.QSpinBox()
        self.read_interval.setRange(50, 3600000)
        self.read_interval.setValue(1000)
        self.read_interval.setSuffix(' ms')
        self.read_interval.setSingleStep(50)
        self.read_interval.setKeyboardTracking(False)
        self.read_interval.setToolTip('普通读取：每轮全部通道结束后等待。扫描中：按此周期轮流读取参与通道位移；读取占用串口，可能增加点间隔。')
        bar.addWidget(self.read_interval)
        bar.addWidget(QtWidgets.QLabel('扫描回读超时'))
        self.scan_read_timeout = QtWidgets.QSpinBox()
        self.scan_read_timeout.setRange(5, 300)
        self.scan_read_timeout.setValue(30)
        self.scan_read_timeout.setSuffix(' ms')
        self.scan_read_timeout.setKeyboardTracking(False)
        self.scan_read_timeout.setToolTip('扫描中单次位移查询的响应等待时间；超时可适当增大，读取可能延长点间隔。')
        bar.addWidget(self.scan_read_timeout)
        self.refresh_button = QtWidgets.QPushButton('读取全部'); self.refresh_button.clicked.connect(self.refresh)
        bar.addWidget(self.refresh_button)
        layout.addLayout(bar)
        self.table = QtWidgets.QTableWidget(0, 8)
        self.table.setHorizontalHeaderLabels(['通道', '开闭环状态', '电压 / V', '位移 / 设备单位', '最近发送目标', '位移偏差（闭环）', '采样时间', '读取状态'])
        self.table.horizontalHeader().setSectionResizeMode(QtWidgets.QHeaderView.ResizeMode.Stretch)
        self.table.setEditTriggers(QtWidgets.QAbstractItemView.EditTrigger.NoEditTriggers)
        self.table.setSelectionBehavior(QtWidgets.QAbstractItemView.SelectionBehavior.SelectRows)
        self.table.itemSelectionChanged.connect(self.selected_row)
        layout.addWidget(self.table, 1)
        self.controls = QtWidgets.QGroupBox('当前通道操作')
        grid = QtWidgets.QGridLayout(self.controls)
        self.channel = QtWidgets.QComboBox()
        grid.addWidget(QtWidgets.QLabel('目标通道'), 0, 0); grid.addWidget(self.channel, 0, 1)
        for col, (label, mode) in enumerate([('设置开环', 'open'), ('设置闭环', 'closed')], 2):
            button = QtWidgets.QPushButton(label)
            button.clicked.connect(lambda checked=False, m=mode: self.submit('mode', mode=m))
            grid.addWidget(button, 0, col)
        self.output = QtWidgets.QComboBox(); self.output.addItems(['电压（开环，V）', '位移（闭环，设备单位）'])
        self.target = self.number(-32767, 32767, 0)
        send = QtWidgets.QPushButton('发送目标值'); send.clicked.connect(lambda: self.submit('target', output=self.output_key(), value=self.target.value()))
        grid.addWidget(self.output, 1, 0); grid.addWidget(self.target, 1, 1); grid.addWidget(send, 1, 2, 1, 2)
        layout.addWidget(self.controls)
        self.wave = QtWidgets.QGroupBox('自定义波形参数 · 设备生成并发波形')
        form = QtWidgets.QGridLayout(self.wave)
        self.kind = QtWidgets.QComboBox(); self.kind.addItems(['正弦波', '方波', '三角波', '锯齿波'])
        self.wave_output = QtWidgets.QComboBox(); self.wave_output.addItems(['电压（开环）', '位移（闭环）'])
        self.peak = self.number(0, 32767, 1)
        self.frequency = self.number(0.0001, 32767, 1)
        self.offset = self.number(-32767, 32767, 0)
        for col, (name, widget) in enumerate([('波形', self.kind), ('输出', self.wave_output), ('峰峰值', self.peak), ('频率 / Hz', self.frequency), ('偏移', self.offset)]):
            form.addWidget(QtWidgets.QLabel(name), 0, col); form.addWidget(widget, 1, col)
        start = QtWidgets.QPushButton('发送波形'); start.clicked.connect(self.start_wave)
        stop = QtWidgets.QPushButton('停止当前通道波形'); stop.clicked.connect(lambda: self.submit('stop'))
        form.addWidget(start, 2, 0, 1, 2); form.addWidget(stop, 2, 2, 1, 3)
        note = QtWidgets.QLabel('使用上方目标通道。峰峰值和偏移单位随输出类型；位移单位及可用范围以设备为准。\n断开连接不代表设备停止输出，请先停止波形。此功能不上传任意点列。')
        note.setWordWrap(True); form.addWidget(note, 3, 0, 1, 5)
        layout.addWidget(self.wave)
        self.log = QtWidgets.QPlainTextEdit(); self.log.setReadOnly(True); self.log.setMaximumHeight(110); self.log.document().setMaximumBlockCount(150)
        layout.addWidget(self.log)
        self.count.valueChanged.connect(self.build_rows)
        self.timer = QtCore.QTimer(self); self.timer.setSingleShot(True); self.timer.timeout.connect(self.poll)
        self.auto.toggled.connect(self.schedule_poll)
        self.read_interval.valueChanged.connect(self.schedule_poll)
        self.scan_read_timeout.valueChanged.connect(self.schedule_poll)
        # Preserve the existing device controls in a separate tab.
        self.takeCentralWidget()
        self.tabs = QtWidgets.QTabWidget()
        self.tabs.addTab(root, '设备控制')
        self.custom = CustomWaveformWidget(self)
        self.tabs.addTab(self.custom, '自定义波形 · Excel')
        self.setCentralWidget(self.tabs)
        self.worker.progress.connect(self.custom.progress_changed)
        self.build_rows(); self.scan_ports(); self.update_enabled()

    @staticmethod
    def number(low, high, value):
        widget = QtWidgets.QDoubleSpinBox(); widget.setDecimals(4); widget.setRange(low, high); widget.setValue(value)
        widget.setKeyboardTracking(False)
        return widget

    def output_key(self):
        return 'voltage' if self.output.currentIndex() == 0 else 'displacement'

    def build_rows(self):
        self.channel.clear(); self.channel.addItems([f'CH{i + 1}' for i in range(self.count.value())])
        self.table.setRowCount(self.count.value())
        for row in range(self.count.value()):
            for col in range(8):
                self.table.setItem(row, col, QtWidgets.QTableWidgetItem(f'CH{row + 1}' if col == 0 else '—'))

    def selected_row(self):
        if self.table.currentRow() >= 0:
            self.channel.setCurrentIndex(self.table.currentRow())

    def scan_ports(self):
        current = self.port.currentText()
        self.port.clear(); self.port.addItems([p.device for p in list_ports.comports()])
        if current:
            self.port.setCurrentText(current)

    def update_enabled(self):
        for widget in (self.port, self.baud, self.address, self.count, self.scan):
            widget.setEnabled(not self.online and not self.busy)
        self.connect_button.setEnabled(not self.busy)
        self.connect_button.setText('断开' if self.online else '连接')
        for widget in (self.controls, self.wave):
            widget.setEnabled(self.online and not self.busy)
        self.refresh_button.setEnabled(self.online and (not self.busy or self.scan_reserved or self.playing_points))
        if hasattr(self, 'custom'):
            self.custom.update_enabled()

    def reserve_for_scan(self):
        if self.closing or self.scan_reserved or self.busy:
            raise RuntimeError('振镜串口正在通信或执行任务，请等待完成后开始匀速扫描。')
        if not self.online or not self.worker.controller.connected:
            raise RuntimeError('请先在振镜控制页连接振镜串口。')
        if self.count.value() < 2:
            raise RuntimeError('振镜联动至少需要2个通道，请在振镜控制页调整通道数。')
        self.scan_reserved = True
        self.busy = True
        self.timer.stop()
        self.update_enabled()
        self.state.setText('匀速扫描联动中 · 可自动刷新或读取位置，手动控制已锁定')
        return self.worker.controller

    def release_from_scan(self):
        if not self.scan_reserved:
            return
        self.scan_reserved = False
        self.busy = False
        self.state.setText('已连接' if self.online else '未连接')
        self.update_enabled()
        if self.closing:
            self.submit('disconnect')
        else:
            self.schedule_poll()

    def submit(self, action, **args):
        if self.busy:
            return
        args.setdefault('channel', self.channel.currentIndex())
        self.last_channel = args['channel']
        self.playing_points = action == 'play'
        self.busy = True; self.timer.stop(); self.update_enabled()
        self.state.setText('通信中…')
        self.request.emit(action, args)

    def toggle_connection(self):
        if self.online:
            self.submit('disconnect')
        elif self.port.currentText().strip():
            self.submit('connect', port=self.port.currentText().strip(), baud=int(self.baud.currentText()), address=self.address.value())
        else:
            self.log.appendPlainText('请选择或输入串口名称')

    def refresh(self):
        if not self.online:
            return
        if self.scan_reserved or self.playing_points:
            channels = (0, 1) if self.scan_reserved else tuple(self.custom.running)
            self.worker.feedback.request(channels)
            self.state.setText('已请求读取扫描通道位置，等待串口调度')
        else:
            self.submit('refresh', count=self.count.value())

    def poll(self):
        if self.online and self.auto.isChecked() and not self.busy:
            self.refresh()

    def schedule_poll(self, _value=None):
        self.worker.feedback.configure(self.auto.isChecked(), self.read_interval.value(), self.scan_read_timeout.value())
        self.timer.stop()
        if self.online and self.auto.isChecked() and not self.busy and not self.closing:
            self.timer.start(self.read_interval.value())

    def start_wave(self):
        self.submit('wave', kind=['sine', 'square', 'triangle', 'sawtooth'][self.kind.currentIndex()],
                    output='voltage' if self.wave_output.currentIndex() == 0 else 'displacement',
                    peak=self.peak.value(), frequency=self.frequency.value(), offset=self.offset.value())

    @QtCore.pyqtSlot(object)
    def display_feedback(self, rows):
        for row in rows:
            channel = row['channel']
            if not 0 <= channel < self.table.rowCount():
                continue
            mode = {'open': '开环', 'closed': '闭环'}.get(row.get('mode'), '未知')
            def number(value):
                return '—' if value is None else f'{value:.4f}'
            target = row.get('target')
            target_text = number(target)
            if target is not None:
                target_text += ' 位移' if row.get('closed') else ' V'
            errors = row.get('errors', [])
            if row.get('scan_feedback'):
                status = ('扫描中读取失败' if errors else '扫描中位移反馈') + f" · {row['read_ms']:.1f} ms"
                voltage = '—（扫描仅读位移）'
            else:
                status = '读取失败' if errors else '正常'
                voltage = number(row.get('voltage'))
            values = [mode, voltage, number(row.get('displacement')), target_text,
                      number(row.get('deviation')), row.get('sampled_at', datetime.now().strftime('%H:%M:%S')), status]
            for col, value in enumerate(values, 1):
                item = QtWidgets.QTableWidgetItem(value)
                item.setToolTip('\n'.join(errors) if errors else
                    '位移为设备回读值；闭环偏差=回读位移-最近发送目标。开环电压目标不与位移相减。')
                self.table.setItem(channel, col, item)

    @QtCore.pyqtSlot(str, object, str)
    def completed(self, action, result, error):
        self.busy = False
        if action == 'play':
            self.playing_points = False
            self.custom.finished(error)
        if not error:
            if action == 'connect':
                self.online = True
            elif action == 'disconnect':
                self.online = False; self.build_rows()
            elif action == 'refresh':
                self.display_feedback(result)
        if error or action != 'refresh':
            labels = {'connect': '连接成功', 'disconnect': '已断开', 'mode': '开闭环设置已回读确认', 'target': '目标值已发送', 'wave': '波形指令已发送', 'stop': '停止波形指令已发送', 'play': '点列任务结束，设备保留最后目标值'}
            prefix = f"CH{getattr(self, 'last_channel', 0) + 1} " if action in ('mode', 'target', 'wave', 'stop') else ''
            self.log.appendPlainText(datetime.now().strftime('%H:%M:%S ') + prefix + (f'失败：{error}' if error else labels.get(action, action)))
        self.state.setText('已连接' if self.online else '未连接')
        self.update_enabled()
        if self.closing:
            if self.online:
                self.submit('disconnect')
            else:
                self.thread.quit()
            return
        if self.online and (action in ('connect', 'mode', 'target') or self.auto.isChecked()):
            self.timer.start(200 if action in ('connect', 'mode', 'target') else self.read_interval.value())
            if not self.auto.isChecked() and action in ('connect', 'mode', 'target'):
                self.refresh()

    def request_shutdown(self):
        if not self.thread.isRunning():
            return True
        if not self.closing:
            for flag in self.worker.cancelled.values():
                flag.set()
            self.closing = True
            self.timer.stop()
            self.setEnabled(False)
            if not self.busy:
                self.submit('disconnect')
        return False

    def closeEvent(self, event):
        if self.request_shutdown():
            event.accept()
        else:
            event.ignore()


if __name__ == '__main__':
    app = QtWidgets.QApplication(sys.argv)
    app.setStyle('Fusion')
    window = Window(); window.show()
    sys.exit(app.exec())
