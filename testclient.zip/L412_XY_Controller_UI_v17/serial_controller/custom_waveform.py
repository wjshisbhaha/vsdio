"""Excel 点列读取与双通道串行调度。"""
from dataclasses import dataclass
from decimal import Decimal, InvalidOperation
import time
from openpyxl import load_workbook
if __package__:
    from .serial_controller import encode_value
else:
    from serial_controller import encode_value


@dataclass(frozen=True)
class Point:
    sequence: str
    value: str
    interval_ms: float
    note: str = ''


def load_points(path, sheet_name=None):
    """首行表头；只读取常量，拒绝公式，避免误用过期公式缓存。"""
    workbook = load_workbook(path, read_only=True, data_only=False)
    try:
        sheet = workbook[sheet_name] if sheet_name else workbook.worksheets[0]
        rows = sheet.iter_rows(values_only=True)
        header = next(rows, ())
        aliases = {'数据间隔': '数据间隔（毫秒）', '数据间隔(ms)': '数据间隔（毫秒）',
                   '数据长度': '数据长度（字节）'}
        columns = {}
        for i, title in enumerate(header):
            name = aliases.get(str(title).strip(), str(title).strip())
            if name in columns:
                raise ValueError(f'重复表头：{name}')
            columns[name] = i
        for key in ('发送数据', '数据间隔（毫秒）'):
            if key not in columns:
                raise ValueError(f'缺少列：{key}')
        points = []
        for row_number, row in enumerate(rows, 2):
            if all(value is None or value == '' for value in row):
                continue
            def get(name, default=None):
                index = columns.get(name)
                return row[index] if index is not None and index < len(row) else default
            try:
                value = get('发送数据')
                interval = get('数据间隔（毫秒）')
                if isinstance(value, bool) or isinstance(interval, bool):
                    raise ValueError('数据和间隔不能为布尔值')
                encode_value(value)
                duration = Decimal(str(interval))
                if not duration.is_finite() or not 1 <= duration <= 86400000:
                    raise ValueError('数据间隔应在 1～86400000 毫秒之间')
                length = get('数据长度（字节）')
                if length not in (None, '') and Decimal(str(length)) != 11:
                    raise ValueError('数据长度固定为 11 字节，请留空或填写 11')
                sequence = get('序列号', len(points) + 1)
                points.append(Point(str(sequence if sequence is not None else len(points) + 1),
                                    str(value), float(duration), str(get('备注', '') or '')))
                if len(points) > 10000:
                    raise ValueError('每通道最多导入 10000 点')
            except (ValueError, InvalidOperation) as exc:
                raise ValueError(f'第 {row_number} 行：{exc}') from exc
        if not points:
            raise ValueError('表格没有可发送的数据')
        return points
    finally:
        workbook.close()


def play_points(controller, plans, cancelled, progress, clock=time.monotonic, sleep=time.sleep, feedback=None):
    """共用时间原点、串行发包。间隔为发完本点后等待的时间，不追赶补发。"""
    if not plans:
        raise ValueError('没有播放计划')
    baud = controller.serial.baudrate
    load = 0
    for plan in plans:
        if not plan['points']:
            raise ValueError('点列不能为空')
        for point in plan['points']:
            encode_value(point.value)
        load += 110 / baud / (min(p.interval_ms for p in plan['points']) / 1000)
    if load > 0.8:
        raise ValueError('点列间隔过短，超过当前波特率可用带宽；请增大间隔或提高波特率')
    # 先完成所有通道模式配置，再建立共同起点。失败时不发送任何点值。
    for plan in plans:
        if cancelled[plan['channel']].is_set():
            continue
        controller.set_channel(plan['channel'])
        controller.stop_waveform()
        controller.set_mode('closed' if plan['closed'] else 'open')
    if feedback is not None:
        feedback.begin({p["channel"]: p["closed"] for p in plans})
    epoch = clock()
    active = {p['channel']: dict(plan=p, index=0, due=epoch, last_report=-1) for p in plans}
    while active:
        for channel in list(active):
            if cancelled[channel].is_set():
                state = active.pop(channel)
                progress(channel, state['index'], len(state['plan']['points']), '已停止发送')
        if not active:
            break
        channel = min(active, key=lambda ch: active[ch]['due'])
        state = active[channel]
        delay = state['due'] - clock()
        if delay > 0:
            if feedback is not None and feedback.step(controller, tuple(active),
                    lambda: all(cancelled[ch].is_set() for ch in active)):
                continue
            sleep(min(delay, 0.01))
            continue
        plan = state['plan']
        if state['index'] == len(plan['points']):
            progress(channel, state['index'], state['index'], '发送完成')
            del active[channel]
            continue
        if cancelled[channel].is_set():
            continue
        point = plan['points'][state['index']]
        controller.set_channel(channel)
        (controller.set_displacement if plan['closed'] else controller.set_voltage)(point.value)
        if feedback is not None:
            feedback.target_sent(channel, point.value, plan['closed'])
        state['index'] += 1
        state['due'] = clock() + point.interval_ms / 1000
        if clock() - state['last_report'] >= 0.05 or state['index'] == len(plan['points']):
            progress(channel, state['index'], len(plan['points']), '发送中')
            state['last_report'] = clock()
