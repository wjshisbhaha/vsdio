"""双通道 Excel 点列界面。"""
from pathlib import Path
from PyQt6 import QtCore, QtWidgets
from openpyxl import load_workbook
if __package__:
    from .custom_waveform import load_points
else:
    from custom_waveform import load_points


class ChannelPanel(QtWidgets.QGroupBox):
    def __init__(self, channel, owner):
        super().__init__(f'通道 {channel + 1}')
        self.channel = channel
        self.owner = owner
        self.points = []
        box = QtWidgets.QVBoxLayout(self)
        bar = QtWidgets.QHBoxLayout()
        self.import_button = QtWidgets.QPushButton('读取 Excel 数据')
        self.import_button.clicked.connect(self.import_file)
        self.closed = QtWidgets.QCheckBox('闭环（不选为开环）')
        bar.addWidget(self.import_button); bar.addWidget(self.closed)
        box.addLayout(bar)
        self.file_label = QtWidgets.QLabel('未导入 · 开环为电压 V，闭环为位移')
        self.file_label.setWordWrap(True); box.addWidget(self.file_label)
        self.table = QtWidgets.QTableWidget(0, 5)
        self.table.setHorizontalHeaderLabels(['序列号', '发送数据', '间隔 / ms', '长度 / 字节', '备注'])
        self.table.horizontalHeader().setSectionResizeMode(QtWidgets.QHeaderView.ResizeMode.Stretch)
        self.table.setEditTriggers(QtWidgets.QAbstractItemView.EditTrigger.NoEditTriggers)
        box.addWidget(self.table, 1)
        self.progress = QtWidgets.QProgressBar(); box.addWidget(self.progress)
        self.status = QtWidgets.QLabel('等待导入'); box.addWidget(self.status)
        actions = QtWidgets.QHBoxLayout()
        self.start = QtWidgets.QPushButton('启动此通道')
        self.start.clicked.connect(lambda: owner.start_channels([channel]))
        self.stop = QtWidgets.QPushButton('停止此通道')
        self.stop.clicked.connect(lambda: owner.stop_channels([channel]))
        actions.addWidget(self.start); actions.addWidget(self.stop); box.addLayout(actions)

    def import_file(self):
        path, _ = QtWidgets.QFileDialog.getOpenFileName(self, '选择点列 Excel', '', 'Excel 工作簿 (*.xlsx)')
        if not path:
            return
        try:
            workbook = load_workbook(path, read_only=True)
            try:
                names = workbook.sheetnames
            finally:
                workbook.close()
            sheet = names[0]
            if len(names) > 1:
                sheet, ok = QtWidgets.QInputDialog.getItem(self, '选择工作表', '工作表', names, 0, False)
                if not ok:
                    return
            points = load_points(path, sheet)
            self.set_points(points)
            self.file_label.setText(f'{Path(path).name} / {sheet}')
        except Exception as exc:
            QtWidgets.QMessageBox.warning(self, '导入失败', str(exc))

    def set_points(self, points):
        self.points = points
        self.table.setRowCount(len(points))
        for row, point in enumerate(points):
            for col, value in enumerate([point.sequence, point.value, point.interval_ms, 11, point.note]):
                item = QtWidgets.QTableWidgetItem(str(value))
                item.setToolTip(str(value))
                self.table.setItem(row, col, item)
        self.table.resizeRowsToContents()
        self.file_label.setText(f'已载入 {len(points)} 点 · 开环为电压 V，闭环为位移')
        self.progress.setRange(0, len(points)); self.progress.setValue(0)
        self.status.setText(f'已导入 {len(points)} 点，间隔合计 {sum(p.interval_ms for p in points) / 1000:g} 秒')


class CustomWaveformWidget(QtWidgets.QWidget):
    def __init__(self, window):
        super().__init__()
        self.window = window
        self.running = set()
        layout = QtWidgets.QVBoxLayout(self)
        title = QtWidgets.QLabel('自定义波形 · Excel 点列')
        title.setStyleSheet('font-size:24px;font-weight:600'); layout.addWidget(title)
        self.connection = QtWidgets.QLabel('请先在“设备控制”页连接串口')
        layout.addWidget(self.connection)
        row = QtWidgets.QHBoxLayout()
        self.panels = [ChannelPanel(i, self) for i in range(2)]
        for panel in self.panels:
            row.addWidget(panel)
        layout.addLayout(row, 1)
        buttons = QtWidgets.QHBoxLayout()
        self.start_both = QtWidgets.QPushButton('双通道同时启动')
        self.start_both.clicked.connect(lambda: self.start_channels([0, 1]))
        self.stop_all = QtWidgets.QPushButton('停止全部点列')
        self.stop_all.clicked.connect(lambda: self.stop_channels([0, 1]))
        buttons.addWidget(self.start_both); buttons.addWidget(self.stop_all); layout.addLayout(buttons)
        note = QtWidgets.QLabel('表头：发送数据、数据间隔（毫秒）；序列号、数据长度（字节）、备注可选。\n'
            '每行发送一次，发完本点后等待所填间隔；最后一行等待结束后完成。数据长度固定 11 字节。\n'
            '启动前按勾选设置并确认开闭环。双通道共用起点，串口依次发包，电脑定时存在误差。\n'
            '运行时支持自动刷新或点击读取全部回读位移；查询占用串口，可能增加点间隔。\n停止仅停止后续点发送，设备保留最后目标值，不自动归零。')
        note.setWordWrap(True); layout.addWidget(note)

    def start_channels(self, channels):
        w = self.window
        if not w.online or w.busy:
            return
        plans = []
        for channel in channels:
            panel = self.panels[channel]
            if channel >= w.count.value() or not panel.points:
                QtWidgets.QMessageBox.warning(self, '无法启动', f'请确认通道 {channel + 1} 存在并已导入数据')
                return
            plans.append({'channel': channel, 'closed': panel.closed.isChecked(), 'points': panel.points[:]})
        for channel in channels:
            w.worker.cancelled[channel].clear()
            self.panels[channel].progress.setValue(0)
            self.panels[channel].status.setText('正在设置模式…')
        self.running = set(channels)
        w.submit('play', plans=plans)

    def stop_channels(self, channels):
        for channel in channels:
            if channel in self.running:
                self.window.worker.cancelled[channel].set()
                self.panels[channel].status.setText('正在停止…')

    def update_enabled(self):
        w = self.window
        self.connection.setText('已连接 · 运行时可在设备控制页查看位移反馈' if w.online else '未连接 · 请在“设备控制”页连接串口')
        for panel in self.panels:
            panel.import_button.setEnabled(not w.busy)
            panel.closed.setEnabled(not w.busy)
            panel.start.setEnabled(w.online and not w.busy)
            panel.stop.setEnabled(panel.channel in self.running)
        self.start_both.setEnabled(w.online and not w.busy and w.count.value() >= 2)
        self.stop_all.setEnabled(bool(self.running))

    @QtCore.pyqtSlot(int, int, int, str)
    def progress_changed(self, channel, sent, total, status):
        panel = self.panels[channel]
        panel.progress.setRange(0, total); panel.progress.setValue(sent)
        panel.status.setText(f'{status} · {sent}/{total}')
        if sent:
            panel.table.selectRow(sent - 1)
        if status in ('发送完成', '已停止发送'):
            self.running.discard(channel)
            self.update_enabled()

    def finished(self, error):
        if error:
            for channel in self.running:
                self.panels[channel].status.setText(f'发送失败：{error}')
        self.running.clear()
        self.update_enabled()
