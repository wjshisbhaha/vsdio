"""基于随附示例协议的串口控制器。运行本文件可使用中文交互菜单。"""

import argparse
from decimal import Decimal, InvalidOperation, ROUND_HALF_UP
from functools import reduce
import time


class ProtocolError(Exception):
    """设备响应不符合协议。"""


def byte_value(value, name):
    if isinstance(value, bool) or not isinstance(value, int) or not 0 <= value <= 255:
        raise ValueError(f"{name}必须是 0～255 的整数")
    return value


def encode_value(value):
    """整数高低字节 + 四位小数高低字节，最高位表示负号。"""
    try:
        number = Decimal(str(value))
        if not number.is_finite():
            raise ValueError("数值必须为有限数")
        if abs(number) > Decimal("32767.9999"):
            raise ValueError("数值超出协议编码范围")
        units = int((abs(number) * 10000).to_integral_value(rounding=ROUND_HALF_UP))
    except InvalidOperation as exc:
        raise ValueError("请输入有效数字") from exc
    whole, fraction = divmod(units, 10000)
    if whole > 32767:
        raise ValueError("数值超出协议编码范围")
    sign = 0x80 if number < 0 and units else 0
    return bytes([(whole >> 8) | sign, whole & 255, fraction >> 8, fraction & 255])


def decode_value(data):
    if len(data) != 4:
        raise ProtocolError("数值数据必须为 4 字节")
    fraction = (data[2] << 8) | data[3]
    if fraction >= 10000:
        raise ProtocolError("小数部分超出四位小数编码范围")
    result = ((data[0] & 0x7F) << 8) + data[1] + fraction / 10000
    return -result if data[0] & 0x80 else result


class SerialController:
    def __init__(self, address=1, channel=0, timeout=1.0):
        self.address = byte_value(address, "设备地址")
        self.channel = byte_value(channel, "通道")
        if not 0 < timeout < float("inf"):
            raise ValueError("超时必须为正的有限数")
        self.timeout = timeout
        self.serial = None

    @property
    def connected(self):
        return self.serial is not None and self.serial.is_open

    def connect(self, port, baudrate=115200):
        import serial

        self.disconnect()
        self.serial = serial.Serial(
            port=port, baudrate=baudrate, bytesize=8, parity="N", stopbits=1,
            timeout=min(0.05, self.timeout), write_timeout=self.timeout,
        )

    def disconnect(self):
        if self.serial is not None:
            self.serial.close()
            self.serial = None

    def set_channel(self, channel):
        """选择后续命令的目标通道；协议通道号从 0 开始。"""
        self.channel = byte_value(channel, "通道")

    def _frame(self, command, payload=b""):
        frame = bytes([0xAA, self.address, 7 + len(payload), command, 0, self.channel]) + payload
        return frame + bytes([reduce(int.__xor__, frame, 0)])

    def _send(self, command, payload=b""):
        if not self.connected:
            raise RuntimeError("请先连接串口")
        frame = self._frame(command, payload)
        if self.serial.write(frame) != len(frame):
            raise ProtocolError("串口数据未完整发送")
        self.serial.flush()

    def _query(self, command, response_length):
        if not self.connected:
            raise RuntimeError("请先连接串口")
        self.serial.reset_input_buffer()
        self._send(command)
        deadline = time.monotonic() + self.timeout
        buffer = bytearray()
        last_error = "未收到匹配的完整响应"
        while time.monotonic() < deadline:
            buffer.extend(self.serial.read(1))
            while buffer:
                start = buffer.find(b"\xaa")
                if start < 0:
                    buffer.clear()
                    break
                del buffer[:start]
                if len(buffer) < 3:
                    break
                length = buffer[2]
                if length not in (7, 8, 11):
                    last_error = "响应长度字段无效"
                    del buffer[0]
                    continue
                if len(buffer) < length:
                    break
                frame = bytes(buffer[:length])
                if reduce(int.__xor__, frame, 0) != 0:
                    last_error = "响应异或校验失败"
                    del buffer[0]
                    continue
                del buffer[:length]
                if (frame[1], frame[3], frame[4], frame[5]) != (self.address, command, 0, self.channel):
                    last_error = "响应地址、命令或通道不匹配"
                    continue
                if length != response_length:
                    last_error = "响应数据长度不匹配"
                    continue
                return frame[6:-1]
        raise TimeoutError(f"读取超时：{last_error}")

    def read_mode(self):
        value = self._query(0x13, 8)[0]
        if value == 0x43:
            return "closed"
        if value == 0x4F:
            return "open"
        raise ProtocolError(f"未知开闭环状态：0x{value:02X}")

    def set_mode(self, mode):
        if mode not in ("open", "closed"):
            raise ValueError("模式必须为 open（开环）或 closed（闭环）")
        self._send(0x12, bytes([0x4F if mode == "open" else 0x43]))
        time.sleep(0.02)
        actual = self.read_mode()
        if actual != mode:
            raise ProtocolError("设备返回的开闭环状态与设置不一致")
        return actual

    def read_voltage(self):
        return decode_value(self._query(0x05, 11))

    def read_displacement(self):
        return decode_value(self._query(0x06, 11))

    def set_voltage(self, voltage):
        """发送电压设定指令；发送完成不代表设备已达到设定电压。"""
        self._send(0x00, encode_value(voltage))

    def set_displacement(self, displacement):
        """发送闭环位移目标，单位依设备为 μm 或 mrad。"""
        self._send(0x01, encode_value(displacement))

    def start_waveform(self, kind, output, peak_to_peak, frequency, offset):
        """C# 示例的单路并发波形，由设备生成。"""
        types = {"sine": 0x5A, "square": 0x46, "triangle": 0x53, "sawtooth": 0x4A}
        if kind not in types or output not in ("voltage", "displacement"):
            raise ValueError("无效波形类型或输出类型")
        values = [encode_value(v) for v in (peak_to_peak, frequency, offset)]
        if Decimal(str(peak_to_peak)) < 0 or Decimal(str(frequency)) < Decimal("0.0001"):
            raise ValueError("峰峰值不能为负，频率不能小于 0.0001 Hz")
        # 验证波形两端至少处于协议可表示的范围内。
        half = Decimal(str(peak_to_peak)) / 2
        encode_value(Decimal(str(offset)) - half)
        encode_value(Decimal(str(offset)) + half)
        self._send(0x0F if output == "voltage" else 0x10,
                   bytes([types[kind]]) + b"".join(values))

    def stop_waveform(self):
        """停止当前通道的并发波形。"""
        self._send(0x11)


def list_ports():
    from serial.tools import list_ports as ports

    found = list(ports.comports())
    for port in found:
        print(f"  {port.device}  {port.description}")
    if not found:
        print("  未发现串口")


def main():
    parser = argparse.ArgumentParser(description="串口电压/位移及开闭环控制")
    parser.add_argument("--port", help="启动时连接的串口，例如 COM5 或 /dev/cu.usbserial-xxx")
    parser.add_argument("--baudrate", type=int, default=115200)
    parser.add_argument("--address", type=int, default=1)
    parser.add_argument("--channel", type=int, default=0)
    parser.add_argument("--timeout", type=float, default=1.0)
    args = parser.parse_args()
    try:
        import serial
    except ImportError:
        parser.exit(1, "缺少 pyserial，请执行：python3 -m pip install -r requirements.txt\n")
    try:
        controller = SerialController(args.address, args.channel, args.timeout)
    except ValueError as exc:
        parser.error(str(exc))
    errors = (ValueError, RuntimeError, ProtocolError, TimeoutError, serial.SerialException, OSError)
    try:
        if args.port:
            try:
                controller.connect(args.port, args.baudrate)
                print(f"已连接 {args.port}")
            except errors as exc:
                print(f"连接失败：{exc}")
        while True:
            status = controller.serial.port if controller.connected else "未连接"
            print(f"\n串口：{status} | 地址：{controller.address} | 通道：{controller.channel}")
            print("1 列出串口  2 连接串口  3 断开串口  4 切换通道")
            print("5 读取开闭环  6 设置开环  7 设置闭环")
            print("8 读取电压  9 读取位移  10 设置并发送电压（开环）")
            print("11 设置并发送位移（闭环）  0 退出")
            choice = input("请选择：").strip()
            try:
                if choice == "0":
                    break
                elif choice == "1":
                    list_ports()
                elif choice == "2":
                    port = input("串口名称：").strip()
                    baudrate = int(input(f"波特率 [{args.baudrate}]：").strip() or args.baudrate)
                    controller.connect(port, baudrate)
                    print("连接成功")
                elif choice == "3":
                    controller.disconnect()
                    print("已断开")
                elif choice == "4":
                    controller.set_channel(int(input("通道号（从 0 开始，以设备支持的通道为准）：")))
                    print(f"后续命令使用通道 {controller.channel}")
                elif choice == "5":
                    print("当前模式：" + ("开环" if controller.read_mode() == "open" else "闭环"))
                elif choice in ("6", "7"):
                    controller.set_mode("open" if choice == "6" else "closed")
                    print("已设置并回读确认：" + ("开环" if choice == "6" else "闭环"))
                elif choice == "8":
                    print(f"电压：{controller.read_voltage():.4f} V")
                elif choice == "9":
                    print(f"位移：{controller.read_displacement():.4f}（单位以设备为准：μm 或 mrad）")
                elif choice == "10":
                    voltage = input("目标电压（V，请遵守设备额定范围）：").strip()
                    controller.set_voltage(voltage)
                    print("电压设定指令已发送，可选择 8 读取实际电压")
                elif choice == "11":
                    displacement = input("目标位移（请先设置闭环，单位及范围以设备为准：μm 或 mrad）：").strip()
                    controller.set_displacement(displacement)
                    print("位移设定指令已发送，可选择 9 读取实际位移")
                else:
                    print("无效选项")
            except errors as exc:
                print(f"操作失败：{exc}")
    except (KeyboardInterrupt, EOFError):
        print("\n退出")
    finally:
        controller.disconnect()


if __name__ == "__main__":
    main()
