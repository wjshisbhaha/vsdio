@echo off
setlocal
cd /d "%~dp0"

rem 模拟模式不加载 DLL，可使用当前 Python 测试主界面通信。
python shutter32_server.py --host 127.0.0.1 --port 37501 --simulate
if errorlevel 1 pause
endlocal
