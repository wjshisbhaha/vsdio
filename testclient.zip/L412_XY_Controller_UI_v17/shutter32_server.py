from __future__ import annotations

import argparse
import ctypes
import json
import signal
import struct
import sys
import threading
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from pathlib import Path
from urllib.parse import urlparse


COMMANDS = {1: 0x8A, 2: 0x4A, 3: 0x2A}
CLOSE_COMMAND = 0x0A

ULONG = ctypes.c_ulong
BOOL = ctypes.c_int
HANDLE = ctypes.c_void_p


class CH375ShutterDevice:
    """
    32 位 CH375 快门封装。

    重要：每次命令严格执行用户已经验证可用的流程：
        CH375OpenDevice(0)
        CH375WriteData(0, buf, 1)
        CH375CloseDevice()

    DLL 只加载一次，但设备句柄不长期占用，避免“检测正常、连接时写入失败”。
    """

    def __init__(self, dll_path: str | Path, device_index: int = 0, simulate: bool = False):
        self.requested_dll_path = Path(dll_path)
        self.dll_path = self._resolve_dll_path(self.requested_dll_path)
        self.device_index = int(device_index)
        self.simulate = bool(simulate)
        self.dll = None
        self.device_open = False
        self.last_open_result = None
        self.last_write_result = None
        self.current_shutter = 0
        self.last_command = CLOSE_COMMAND
        self.last_error = ""
        self._lock = threading.RLock()

    @property
    def architecture_bits(self) -> int:
        return struct.calcsize("P") * 8

    @staticmethod
    def _resolve_dll_path(path: Path) -> Path:
        """优先精确路径；找不到时在同目录按文件名大小写不敏感搜索。"""
        path = path.expanduser()
        if not path.is_absolute():
            path = (Path.cwd() / path).resolve()
        else:
            path = path.resolve()
        if path.exists():
            return path

        parent = path.parent
        if parent.exists():
            target = path.name.casefold()
            for item in parent.iterdir():
                if item.is_file() and item.name.casefold() == target:
                    return item.resolve()
            # 同时兼容用户明确给出的 CH375DLL.DLL。
            for item in parent.iterdir():
                if item.is_file() and item.name.casefold() == "ch375dll.dll":
                    return item.resolve()
        return path

    def load_library(self) -> None:
        with self._lock:
            if self.simulate:
                print("[模拟] 不加载 CH375DLL.DLL")
                return
            if self.dll is not None:
                return
            if sys.platform != "win32":
                raise RuntimeError("CH375DLL.DLL 只能在 Windows 下加载。")
            if self.architecture_bits != 32:
                raise RuntimeError(
                    f"当前 Python 是 {self.architecture_bits} 位；CH375DLL.DLL 必须由 32 位 Python 加载。"
                )
            if not self.dll_path.exists():
                raise FileNotFoundError(
                    "未找到 CH375DLL.DLL。\n"
                    f"请求路径：{self.requested_dll_path}\n"
                    f"解析路径：{self.dll_path}\n"
                    "请把 CH375DLL.DLL 与 shutter32_server.py 放在同一目录。"
                )

            try:
                self.dll = ctypes.WinDLL(str(self.dll_path), use_last_error=True)
            except OSError as exc:
                raise RuntimeError(
                    f"加载 DLL 失败：{self.dll_path}\n{exc}\n"
                    "请确认：DLL 为 32 位、Python 为 32 位，并且 DLL 依赖文件完整。"
                ) from exc

            # HANDLE WINAPI CH375OpenDevice(ULONG iIndex)
            self.dll.CH375OpenDevice.argtypes = [ULONG]
            self.dll.CH375OpenDevice.restype = HANDLE

            # BOOL WINAPI CH375WriteData(ULONG iIndex, PVOID iBuffer, PULONG ioLength)
            self.dll.CH375WriteData.argtypes = [
                ULONG,
                ctypes.c_void_p,
                ctypes.POINTER(ULONG),
            ]
            self.dll.CH375WriteData.restype = BOOL

            # VOID WINAPI CH375CloseDevice(ULONG iIndex)
            self.dll.CH375CloseDevice.argtypes = [ULONG]
            self.dll.CH375CloseDevice.restype = None
            print(f"[CH375] DLL 已加载：{self.dll_path}")

    def _open_device(self) -> int:
        if self.simulate:
            self.device_open = True
            self.last_open_result = 1
            print("[模拟] CH375OpenDevice(0) -> 1")
            return 1
        self.load_library()
        if self.dll is None:
            raise RuntimeError("CH375DLL.DLL 尚未加载。")

        ctypes.set_last_error(0)
        raw_handle = self.dll.CH375OpenDevice(ULONG(self.device_index))
        result = None if raw_handle is None else int(raw_handle)
        self.last_open_result = result
        last_error = ctypes.get_last_error()
        invalid_handle = (1 << (self.architecture_bits)) - 1
        if result in (None, 0, invalid_handle):
            message = f"CH375OpenDevice({self.device_index}) 失败，返回无效句柄 {result}"
            if last_error:
                message += f"，WinError={last_error}"
            raise RuntimeError(message + "。请检查驱动、USB 连接和设备索引。")
        self.device_open = True
        print(f"[CH375] OpenDevice index={self.device_index}, handle={result}")
        return result

    def _close_device(self) -> int:
        if not self.device_open:
            return 1
        try:
            if self.simulate:
                result = 1
                print("[模拟] CH375CloseDevice() -> 1")
            else:
                if self.dll is None:
                    return 0
                ctypes.set_last_error(0)
                self.dll.CH375CloseDevice(ULONG(self.device_index))
                result = 1
                last_error = ctypes.get_last_error()
                print(
                    f"[CH375] CloseDevice index={self.device_index}, "
                    f"WinError={last_error}"
                )
            return result
        finally:
            self.device_open = False

    def probe_device(self) -> dict:
        """真实探测：加载 DLL，并实际执行一次 OpenDevice/CloseDevice，不发送快门命令。"""
        with self._lock:
            self.last_error = ""
            try:
                open_result = self._open_device()
                close_result = self._close_device()
                return {"open_result": open_result, "close_result": close_result}
            except Exception as exc:
                self.last_error = str(exc)
                try:
                    self._close_device()
                except Exception:
                    pass
                raise

    def write_command(self, value: int) -> int:
        value = int(value) & 0xFF
        with self._lock:
            self.last_error = ""
            opened = False
            try:
                self._open_device()
                opened = True
                if self.simulate:
                    result = 1
                    print(f"[模拟] CH375WriteData({self.device_index}, 0x{value:02X}, 1) -> 1")
                else:
                    if self.dll is None:
                        raise RuntimeError("CH375DLL.DLL 尚未加载。")
                    buf = (ctypes.c_ubyte * 1)(value)
                    length = ULONG(1)
                    ctypes.set_last_error(0)
                    result = int(
                        self.dll.CH375WriteData(
                            ULONG(self.device_index),
                            ctypes.cast(buf, ctypes.c_void_p),
                            ctypes.byref(length),
                        )
                    )
                    last_error = ctypes.get_last_error()
                    if result == 0:
                        raise RuntimeError(
                            f"CH375WriteData(0, 0x{value:02X}, &length) 失败，"
                            f"返回 0，WinError={last_error}。"
                        )
                    if length.value != 1:
                        raise RuntimeError(
                            f"CH375WriteData 返回成功，但实际写入长度为 {length.value}，预期为 1。"
                        )
                    print(
                        f"[CH375] WriteData index={self.device_index}, "
                        f"value=0x{value:02X}, actual_length={length.value}, result={result}"
                    )
                self.last_write_result = result
                self.last_command = value
                return result
            except Exception as exc:
                self.last_error = str(exc)
                raise
            finally:
                if opened or self.device_open:
                    try:
                        self._close_device()
                    except Exception as close_exc:
                        print(f"[警告] 命令执行后关闭设备失败：{close_exc}")

    def open_shutter(self, shutter_no: int) -> int:
        shutter_no = int(shutter_no)
        if shutter_no not in COMMANDS:
            raise ValueError("快门编号只能是 1、2 或 3。")
        result = self.write_command(COMMANDS[shutter_no])
        self.current_shutter = shutter_no
        return result

    def write_shutter_command(self, value: int) -> int:
        value = int(value) & 0xFF
        allowed_values = {CLOSE_COMMAND}
        commands = list(COMMANDS.values())
        for index, command in enumerate(commands):
            allowed_values.add(command)
            for other in commands[index + 1:]:
                allowed_values.add(command | other)
        allowed_values.add(commands[0] | commands[1] | commands[2])
        if value not in allowed_values:
            raise ValueError(f"不支持的快门组合命令：0x{value:02X}")
        result = self.write_command(value)
        self.current_shutter = value
        return result

    def close_shutter(self) -> int:
        result = self.write_command(CLOSE_COMMAND)
        self.current_shutter = 0
        return result

    def state(self) -> dict:
        return {
            "connected": self.dll is not None or self.simulate,
            "dll_loaded": self.dll is not None or self.simulate,
            "device_open": self.device_open,
            "device_index": self.device_index,
            "architecture_bits": self.architecture_bits,
            "simulate": self.simulate,
            "current_shutter": self.current_shutter,
            "last_command": f"0x{self.last_command:02X}",
            "last_open_result": self.last_open_result,
            "last_write_result": self.last_write_result,
            "last_error": self.last_error,
            "dll_path": str(self.dll_path),
            "requested_dll_path": str(self.requested_dll_path),
        }

    def shutdown(self) -> None:
        """服务退出时尽力发送 0x0A，然后确保设备关闭。"""
        with self._lock:
            try:
                self.close_shutter()
            except Exception as exc:
                print(f"[警告] 服务退出时发送 0x0A 失败：{exc}")
            try:
                self._close_device()
            except Exception as exc:
                print(f"[警告] 服务退出时关闭设备失败：{exc}")
            self.dll = None


class ShutterRequestHandler(BaseHTTPRequestHandler):
    server_version = "CH375ShutterBridge/2.0"

    @property
    def device(self) -> CH375ShutterDevice:
        return self.server.device  # type: ignore[attr-defined]

    def log_message(self, fmt: str, *args) -> None:
        print(f"[HTTP] {self.address_string()} - {fmt % args}")

    def _send_json(self, status: int, payload: dict) -> None:
        raw = json.dumps(payload, ensure_ascii=False).encode("utf-8")
        self.send_response(status)
        self.send_header("Content-Type", "application/json; charset=utf-8")
        self.send_header("Content-Length", str(len(raw)))
        self.end_headers()
        self.wfile.write(raw)

    def _ok(self, **extra) -> None:
        self._send_json(200, {"ok": True, **self.device.state(), **extra})

    def _error(self, exc: Exception, status: int = 500) -> None:
        self._send_json(status, {"ok": False, "error": str(exc), **self.device.state()})

    def do_GET(self) -> None:
        path = urlparse(self.path).path
        try:
            if path in ("/", "/health"):
                self._ok(service="CH375 32-bit shutter bridge", service_version="2.0")
            elif path == "/probe":
                result = self.device.probe_device()
                self._ok(probe=True, **result)
            elif path == "/state":
                self._ok()
            else:
                self._send_json(404, {"ok": False, "error": f"未知路径：{path}"})
        except Exception as exc:
            self._error(exc)

    def do_POST(self) -> None:
        path = urlparse(self.path).path
        try:
            if path.startswith("/open/"):
                shutter_no = int(path.rsplit("/", 1)[-1])
                result = self.device.open_shutter(shutter_no)
                self._ok(result=result, command=f"0x{COMMANDS[shutter_no]:02X}")
            elif path.startswith("/command/"):
                raw = path.rsplit("/", 1)[-1]
                value = int(raw, 0)
                result = self.device.write_shutter_command(value)
                self._ok(result=result, command=f"0x{value & 0xFF:02X}")
            elif path == "/close":
                result = self.device.close_shutter()
                self._ok(result=result, command=f"0x{CLOSE_COMMAND:02X}")
            else:
                self._send_json(404, {"ok": False, "error": f"未知路径：{path}"})
        except ValueError as exc:
            self._error(exc, 400)
        except Exception as exc:
            self._error(exc)


class ShutterHTTPServer(ThreadingHTTPServer):
    daemon_threads = True
    allow_reuse_address = True

    def __init__(self, address, handler, device: CH375ShutterDevice):
        super().__init__(address, handler)
        self.device = device


def parse_args():
    parser = argparse.ArgumentParser(description="CH375 32 位快门本地桥接服务")
    parser.add_argument("--host", default="127.0.0.1", help="监听地址，默认仅本机")
    parser.add_argument("--port", type=int, default=37501, help="监听端口")
    parser.add_argument("--device-index", type=int, default=0, help="CH375 设备索引")
    parser.add_argument(
        "--dll",
        default=str(Path(__file__).resolve().with_name("CH375DLL.DLL")),
        help="CH375DLL.DLL 路径",
    )
    parser.add_argument("--simulate", action="store_true", help="不加载 DLL，仅模拟命令")
    return parser.parse_args()


def main() -> int:
    args = parse_args()
    device = CH375ShutterDevice(args.dll, args.device_index, args.simulate)
    try:
        # 启动时只加载 DLL，不长期打开设备；每次命令自行 Open/Write/Close。
        device.load_library()
    except Exception as exc:
        print(f"[启动失败] {exc}")
        return 1

    server = ShutterHTTPServer((args.host, args.port), ShutterRequestHandler, device)
    stop_event = threading.Event()

    def stop_server(*_):
        if stop_event.is_set():
            return
        stop_event.set()
        print("\n[服务] 正在停止……")
        threading.Thread(target=server.shutdown, daemon=True).start()

    signal.signal(signal.SIGINT, stop_server)
    if hasattr(signal, "SIGTERM"):
        signal.signal(signal.SIGTERM, stop_server)

    print(f"[服务] Python 位数：{device.architecture_bits}")
    print(f"[服务] DLL：{device.dll_path}")
    print(f"[服务] 地址：http://{args.host}:{args.port}")
    print("[服务] 命令模式：每次 OpenDevice -> WriteData -> CloseDevice")
    print("[服务] 命令：快门1=0x8A，快门2=0x4A，快门3=0x2A，关闭=0x0A")
    try:
        server.serve_forever(poll_interval=0.2)
    finally:
        server.server_close()
        device.shutdown()
        print("[服务] 已停止")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
