@echo off
setlocal
cd /d "%~dp0"

rem ===== 修改为你的 32 位 Python 路径 =====
set "PYTHON32=C:\Python311-32\python.exe"

if not exist "%PYTHON32%" (
    echo [ERROR] 32-bit Python not found: %PYTHON32%
    pause
    exit /b 1
)

"%PYTHON32%" diagnose_ch375_32.py
pause
endlocal
